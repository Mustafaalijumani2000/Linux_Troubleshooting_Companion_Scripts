# Linux Troubleshooting the Automated Way — companion scripts

Author: MAG JUMANI · Edition: November 2026

- 40 read-only lab scripts, one per workbook lab.
- One Python 3.6+ `health_report.py` report generator for disk, RAM, CPU, and combined HTML reports.
- `--send` is **opt-in**. Without it, HTML is written locally.
- Reports have illustrative threshold colors; calibrate thresholds to workload.
- Filesystem usage does **not** prove physical disk health; SMART requires `smartmontools`, privileges and exposed devices.
- Memory pressure is **not** a physical RAM test; CPU utilization is **not** an electronic CPU hardware test.
- On Oracle Linux/RHEL 7, Python 3 may not be installed. Provision a supported Python 3 version from an approved repository.
- Some probe commands require optional tools or root privileges; missing evidence is not proof of health.

## Basic use

```bash
bash lab01_root_filesystem_at_95.sh
python3 health_report.py --kind disk --output /tmp/disk.html
python3 health_report.py --kind ram --output /tmp/ram.html
python3 health_report.py --kind cpu --output /tmp/cpu.html
```

## Email setup (approved SMTP relay)

```bash
export SMTP_HOST='smtp.example.internal'
export SMTP_PORT=587
export SMTP_FROM='linux-reports@example.internal'
export SMTP_TO='ops@example.internal'
export SMTP_USER='approved-service-user'
# Supply SMTP_PASSWORD through your secret manager, NOT command history.
python3 health_report.py --kind all --send
```

`SMTP_SSL=1` enables implicit TLS (usually port 465); otherwise STARTTLS is required. Do not disable TLS verification. Reports can reveal infrastructure details; restrict recipients and protect credentials. SMTP account app passwords may be necessary depending on the provider.

## Scheduling

Use an approved cron job or systemd timer; secure `EnvironmentFile` paths and permissions (`0600`) when needed. For recurring email, test locally first, then test the mail relay to an authorized recipient. See the appendices in the book.

## Version-specific automation

All 40 incidents have separate Ubuntu 20.04/22.04/24.04, Oracle Linux 7/8/9, and RHEL 7/8/9 command branches in `os_specific_runbooks.sh`. Each numbered lab script invokes this safe read-only dispatcher after the general baseline.
