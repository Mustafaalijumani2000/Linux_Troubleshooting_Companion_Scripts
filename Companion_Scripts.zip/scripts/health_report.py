#!/usr/bin/env python3
"""Read-only Linux disk, RAM, and CPU status report for Python 3.6+.

Examples:
  python3 health_report.py --kind disk --output disk.html
  python3 health_report.py --kind ram --output ram.html
  python3 health_report.py --kind cpu --output cpu.html
  python3 health_report.py --kind all --send

SMTP configuration is read from environment variables. Never hard-code secrets.
An HTML report is created locally by default; --send requires explicit SMTP settings.
"""
import argparse
import datetime
import html
import os
import shutil
import smtplib
import socket
import subprocess
import sys
import time
from email.message import EmailMessage

NAVY = '#102238'
TEAL = '#06b6d4'
GREEN = '#1d9d73'
AMBER = '#b47b13'
RED = '#c53648'


def run(cmd, timeout=12):
    try:
        return subprocess.check_output(cmd, stderr=subprocess.STDOUT,
                                       universal_newlines=True, timeout=timeout).strip()
    except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
        return 'Unavailable ({})'.format(type(exc).__name__)


def escaped(value):
    return html.escape(str(value), quote=True)


def grade(percent, warn=75, critical=90):
    if percent >= critical:
        return ('CRITICAL', RED)
    if percent >= warn:
        return ('WATCH', AMBER)
    return ('NORMAL', GREEN)


def bar(label, value, suffix='%', detail='', warn=75, critical=90):
    value = max(0.0, min(100.0, float(value)))
    state, color = grade(value, warn, critical)
    return ('<div style="margin:18px 0">'
            '<div style="display:flex;justify-content:space-between">'
            '<span style="font-weight:bold">{}</span>'
            '<span style="color:{};font-weight:bold">{:.1f}{} · {}</span></div>'
            '<div style="height:13px;border-radius:8px;background:#e8edf3;overflow:hidden;margin-top:8px">'
            '<div style="height:13px;width:{:.1f}%;background:{};border-radius:8px"></div></div>'
            '<div style="color:#66768a;font-size:12px;margin-top:5px">{}</div></div>').format(
                escaped(label), color, value, escaped(suffix), state, value,
                color, escaped(detail))


def card(title, value, note):
    return ('<td style="width:33%;padding:10px;vertical-align:top">'
            '<div style="background:#f4f8fb;border:1px solid #dce8f0;border-radius:12px;padding:18px">'
            '<div style="font-size:12px;color:#5d7187">{}</div>'
            '<div style="font-size:25px;font-weight:800;color:{};margin-top:5px">{}</div>'
            '<div style="font-size:11px;color:#6c7f90">{}</div>'
            '</div></td>').format(escaped(title), NAVY, escaped(value), escaped(note))


def table(headers, rows):
    head = ''.join('<th style="padding:12px;text-align:left;border-bottom:2px solid #d5e1ec;background:#e8f4f8">{}</th>'.format(escaped(x)) for x in headers)
    body = ''
    for row in rows:
        cells = ''.join('<td style="padding:11px;border-bottom:1px solid #e8edf3;word-break:break-word">{}</td>'.format(escaped(x)) for x in row)
        body += '<tr>{}</tr>'.format(cells)
    return '<table cellspacing="0" cellpadding="0" style="border-collapse:collapse;width:100%;font-size:13px">' + '<thead><tr>' + head + '</tr></thead><tbody>' + body + '</tbody></table>'


def meminfo():
    result = {}
    try:
        with open('/proc/meminfo', 'r') as f:
            for line in f:
                if ':' in line:
                    name, value = line.split(':', 1)
                    result[name] = int(value.strip().split()[0]) * 1024
    except (OSError, ValueError, IndexError):
        pass
    return result


def percent(total, used):
    return 100 * float(used) / float(total) if total else 0.0


def human(n):
    val = float(n)
    for unit in ('B','KiB','MiB','GiB','TiB'):
        if abs(val) < 1024.0:
            return '{:.1f} {}'.format(val, unit)
        val /= 1024.0
    return '{:.1f} PiB'.format(val)


def disk_section():
    mounts = []
    # -P: portable one-line-per-filesystem; -k: 1 KiB units
    data = run(['df', '-Pk', '-x', 'tmpfs', '-x', 'devtmpfs'])
    for line in data.splitlines()[1:]:
        parts = line.split()
        if len(parts) >= 6:
            try:
                total = int(parts[1]) * 1024
                used = int(parts[2]) * 1024
                utilization = percent(total, used)
                mounts.append((parts[5], parts[0], total, used, utilization))
            except ValueError:
                pass
    if not mounts:
        return '<p>Filesystem statistics unavailable.</p>', 'N/A', 'No mount metrics available'
    worst = max(v[4] for v in mounts)
    rows = [(mount, device, human(used), human(total), '{:.1f}%'.format(pct))
            for mount, device, total, used, pct in mounts[:35]]
    chart = ''.join(bar(mount + ' capacity', pct, detail=device)
                    for mount, device, total, used, pct in sorted(mounts, key=lambda v: -v[4])[:5])
    # SMART is not necessarily visible through VM or USB pass-through.
    smart_rows = []
    if shutil.which('smartctl') and shutil.which('lsblk'):
        devices = run(['lsblk', '-dn', '-o', 'NAME,TYPE']).splitlines()
        for line in devices:
            bits = line.split()
            if len(bits) == 2 and bits[1] == 'disk':
                dev = '/dev/' + bits[0]
                smart_rows.append((dev, run(['smartctl', '-H', dev], timeout=8)[-280:]))
    smart = table(['Device', 'SMART output (best effort)'], smart_rows) if smart_rows else '<p>SMART status unavailable: install smartmontools, grant safe read permissions, or inspect the physical host. Virtual machines often hide drive SMART data.</p>'
    section = ('<h2>Filesystem capacity</h2>' + chart + table(['Mount','Device','Used','Total','Used %'], rows)
               + '<h2>Physical drive SMART (optional)</h2>' + smart
               + '<p style="font-size:12px;color:#66768a">Filesystem fullness is not a hardware-failure test. A normal capacity result does not prove disk health.</p>')
    return section, '{:.1f}%'.format(worst), '{} filesystems checked'.format(len(mounts))


def memory_section():
    m = meminfo()
    total = m.get('MemTotal', 0)
    available = m.get('MemAvailable', m.get('MemFree', 0))
    used = max(total - available, 0)
    swap_total = m.get('SwapTotal', 0)
    swap_free = m.get('SwapFree', 0)
    swap_used = max(swap_total - swap_free, 0)
    usage = percent(total, used)
    body = ('<h2>RAM and swap pressure</h2>'
            + bar('RAM effective utilization', usage,
                  detail='Based on MemAvailable, not Linux cached-memory totals')
            + (bar('Swap utilization', percent(swap_total, swap_used),
                   detail='Persistent swap growth can justify deeper investigation') if swap_total else '<p>No swap configured.</p>')
            + table(['Metric', 'Observed'], [('Total RAM', human(total)),
                                           ('Available RAM', human(available)),
                                           ('Effective used RAM', human(used)),
                                           ('Swap used', human(swap_used)),
                                           ('Swap total', human(swap_total))])
            + '<p style="font-size:12px;color:#66768a">This is memory utilization and pressure monitoring, not a physical RAM diagnostic or ECC error test.</p>')
    return body, '{:.1f}%'.format(usage), human(available) + ' available'


def cpu_ticks():
    try:
        with open('/proc/stat') as f:
            data = list(map(int, f.readline().split()[1:]))
        idle = data[3] + (data[4] if len(data) > 4 else 0)
        return idle, sum(data)
    except (OSError, ValueError, IndexError):
        return 0, 0


def cpu_section():
    i1, t1 = cpu_ticks()
    time.sleep(1.0)
    i2, t2 = cpu_ticks()
    diff = t2 - t1
    usage = max(0.0, min(100.0, 100 * (1 - float(i2-i1) / diff))) if diff > 0 else 0
    try:
        one, five, fifteen = os.getloadavg()
    except (OSError, AttributeError):
        one, five, fifteen = 0, 0, 0
    cores = os.cpu_count() or 1
    body = ('<h2>CPU utilization and scheduler load</h2>'
            + bar('CPU busy - one-second sample', usage,
                  detail='Short samples can miss intermittent saturation')
            + table(['Metric','Observed'], [('Logical CPUs', cores),
                                          ('1-minute load average','{:.2f}'.format(one)),
                                          ('5-minute load average','{:.2f}'.format(five)),
                                          ('15-minute load average','{:.2f}'.format(fifteen)),
                                          ('1-minute load / logical CPUs','{:.2f}'.format(one / cores))])
            + '<p style="font-size:12px;color:#66768a">Linux load also includes uninterruptible waits. CPU use is not a physical CPU-health or temperature test.</p>')
    return body, '{:.1f}%'.format(usage), '{:.2f} one-minute load'.format(one)


def render(kind, host, sections, summary):
    names = {'disk':'DISK CAPACITY & SMART', 'ram':'RAM & SWAP',
             'cpu':'CPU UTILIZATION', 'all':'SYSTEM HEALTH'}
    now = datetime.datetime.now(datetime.timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
    cards = '<table style="width:100%;border-collapse:collapse"><tr>' + ''.join(card(*c) for c in summary[:3]) + '</tr></table>'
    parts = ('<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>'
             '<body style="margin:0;padding:24px;background:#eaf0f5;font-family:Arial,sans-serif;color:#182c40">'
             '<div style="max-width:920px;margin:auto;background:white;border-radius:18px;overflow:hidden;box-shadow:0 8px 32px #bbc8d3">'
             '<div style="background:{};padding:34px 38px;color:white">'
             '<div style="color:#5de0ec;letter-spacing:3px;font-size:12px;font-weight:bold">AUTOMATED LINUX OPERATIONS REPORT</div>'
             '<h1 style="font-size:30px;line-height:1.2;margin:12px 0">{}</h1>'
             '<div style="font-size:13px;color:#b9cddd">Host: {} &nbsp; | &nbsp; {}</div></div>'
             '<div style="padding:26px 30px">{}{}'
             '<div style="border-top:1px solid #e2e8ef;margin-top:26px;padding-top:16px;font-size:12px;color:#66768a">'
             'Generated by an example Linux health-report automation. Verify readings against host monitoring; missing metrics are explicitly reported. '
             'Do not publish this report to the open internet.</div></div></div></body></html>').format(
                NAVY, escaped(names[kind]), escaped(host), now, cards,
                ''.join('<div style="margin-top:26px">{}</div>'.format(s) for s in sections))
    return parts


def main():
    p = argparse.ArgumentParser(description='Read-only Linux HTML health report')
    p.add_argument('--kind', choices=['disk','ram','cpu','all'], default='all')
    p.add_argument('--output', default=None)
    p.add_argument('--send', action='store_true', help='Send via SMTP (credentials from env)')
    args = p.parse_args()
    hostname = socket.gethostname()
    kinds = ['disk','ram','cpu'] if args.kind == 'all' else [args.kind]
    funcs = {'disk':disk_section,'ram':memory_section,'cpu':cpu_section}
    sections, summary = [], []
    for kind in kinds:
        content, reading, note = funcs[kind]()
        sections.append(content)
        summary.append((kind.upper(), reading, note))
    result = render(args.kind, hostname, sections, summary)
    dest = args.output or 'linux-{}-health.html'.format(args.kind)
    with open(dest, 'w', encoding='utf-8') as f:
        f.write(result)
    print('HTML report written: ' + dest)
    if args.send:
        required = ('SMTP_HOST','SMTP_FROM','SMTP_TO')
        missing = [key for key in required if not os.environ.get(key)]
        if missing:
            raise SystemExit('Missing SMTP configuration: ' + ', '.join(missing))
        msg = EmailMessage()
        msg['Subject'] = '[{}] Linux {} report'.format(hostname, args.kind.upper())
        msg['From'] = os.environ['SMTP_FROM']
        msg['To'] = os.environ['SMTP_TO']
        msg.set_content('Linux health report for {}. View the HTML alternative.'.format(hostname))
        msg.add_alternative(result, subtype='html')
        port = int(os.environ.get('SMTP_PORT', '587'))
        if os.environ.get('SMTP_SSL','0') == '1':
            conn = smtplib.SMTP_SSL(os.environ['SMTP_HOST'], port, timeout=25)
        else:
            conn = smtplib.SMTP(os.environ['SMTP_HOST'], port, timeout=25)
        with conn as smtp:
            if os.environ.get('SMTP_SSL','0') != '1':
                smtp.starttls()
            if os.environ.get('SMTP_USER'):
                smtp.login(os.environ['SMTP_USER'],os.environ.get('SMTP_PASSWORD',''))
            smtp.send_message(msg)
        print('SMTP handoff completed; confirm recipient delivery separately.')


if __name__ == '__main__':
    main()
