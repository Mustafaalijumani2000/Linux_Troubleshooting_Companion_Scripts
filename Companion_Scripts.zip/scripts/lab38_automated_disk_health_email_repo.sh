#!/usr/bin/env bash
# LAB 38: Automated disk HTML email report; dry-run by default.
# Prerequisite: Python 3.6+ on the host; configure SMTP only when sending.
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if ! command -v python3 >/dev/null 2>&1; then
  printf '%s\n' 'Python 3 is unavailable; check approved OS repositories.' >&2
  exit 2
fi
exec python3 "$HERE/health_report.py" --kind disk "$@"
