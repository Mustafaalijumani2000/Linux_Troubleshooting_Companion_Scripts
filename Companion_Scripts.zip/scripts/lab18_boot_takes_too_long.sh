#!/usr/bin/env bash
# Lab 18: Boot takes too long
# Runnable wrapper; all nine OS branches live in the dispatcher.
set -euo pipefail
export LC_ALL=C
umask 077
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
. /etc/os-release
printf "Selected OS: %s %s\n" "$ID" "$VERSION_ID"
# Diagnostics are bounded; no automated remediation.
exec bash "$HERE/os_specific_runbooks.sh" 18
