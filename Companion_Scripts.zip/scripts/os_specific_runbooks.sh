#!/usr/bin/env bash
# OS-specific automated runbooks for all 40 labs and all nine release targets.
# Read-only probes only; never automatically alters system state.
set -u
export LC_ALL=C
if [ $# -ne 1 ]; then echo "Usage: $0 LAB_NUMBER" >&2; exit 2; fi
lab=$((10#$1))
if [ -r /etc/os-release ]; then . /etc/os-release; else echo "Missing /etc/os-release" >&2; exit 2; fi
os_id=${ID:-unknown}; os_major=${VERSION_ID%%.*}
printf "OS-specific checks: %s %s lab %02d
" "$os_id" "$VERSION_ID" "$lab"
run_check() {
  label="$1"; cmd="$2"
  printf "
[%s] $ %s
" "$label" "$cmd"
  if command -v timeout >/dev/null 2>&1; then
    timeout 12 bash -c "$cmd" 2>&1 | head -n 32
  else bash -c "$cmd" 2>&1 | head -n 32; fi
}
case "$os_id:$os_major:$lab" in
  ubuntu:20:1)
    run_check 'Check 1' 'df -hT /'
    run_check 'Check 2' 'du -xhd1 /var 2>/dev/null | sort -h'
    run_check 'Check 3' 'find /var -xdev -type f -size +100M -print 2>/dev/null'
    ;;
  ubuntu:22:1)
    run_check 'Check 1' 'df -hT /'
    run_check 'Check 2' 'du -xhd1 /var 2>/dev/null | sort -h'
    run_check 'Check 3' 'find /var -xdev -type f -size +100M -print 2>/dev/null'
    ;;
  ubuntu:24:1)
    run_check 'Check 1' 'df -hT /'
    run_check 'Check 2' 'du -xhd1 /var 2>/dev/null | sort -h'
    run_check 'Check 3' 'find /var -xdev -type f -size +100M -print 2>/dev/null'
    ;;
  ol:7:1)
    run_check 'Check 1' 'df -hT /'
    run_check 'Check 2' 'du -xhd1 /var 2>/dev/null | sort -h'
    run_check 'Check 3' 'find /var -xdev -type f -size +100M -print 2>/dev/null'
    ;;
  ol:8:1)
    run_check 'Check 1' 'df -hT /'
    run_check 'Check 2' 'du -xhd1 /var 2>/dev/null | sort -h'
    run_check 'Check 3' 'find /var -xdev -type f -size +100M -print 2>/dev/null'
    ;;
  ol:9:1)
    run_check 'Check 1' 'df -hT /'
    run_check 'Check 2' 'du -xhd1 /var 2>/dev/null | sort -h'
    run_check 'Check 3' 'find /var -xdev -type f -size +100M -print 2>/dev/null'
    ;;
  rhel:7:1)
    run_check 'Check 1' 'df -hT /'
    run_check 'Check 2' 'du -xhd1 /var 2>/dev/null | sort -h'
    run_check 'Check 3' 'find /var -xdev -type f -size +100M -print 2>/dev/null'
    ;;
  rhel:8:1)
    run_check 'Check 1' 'df -hT /'
    run_check 'Check 2' 'du -xhd1 /var 2>/dev/null | sort -h'
    run_check 'Check 3' 'find /var -xdev -type f -size +100M -print 2>/dev/null'
    ;;
  rhel:9:1)
    run_check 'Check 1' 'df -hT /'
    run_check 'Check 2' 'du -xhd1 /var 2>/dev/null | sort -h'
    run_check 'Check 3' 'find /var -xdev -type f -size +100M -print 2>/dev/null'
    ;;
  ubuntu:20:2)
    run_check 'Check 1' 'df -i /var'
    run_check 'Check 2' 'find /var -xdev -type f | wc -l'
    run_check 'Check 3' 'du -xhd1 /var 2>/dev/null | sort -h'
    ;;
  ubuntu:22:2)
    run_check 'Check 1' 'df -i /var'
    run_check 'Check 2' 'find /var -xdev -type f | wc -l'
    run_check 'Check 3' 'du -xhd1 /var 2>/dev/null | sort -h'
    ;;
  ubuntu:24:2)
    run_check 'Check 1' 'df -i /var'
    run_check 'Check 2' 'find /var -xdev -type f | wc -l'
    run_check 'Check 3' 'du -xhd1 /var 2>/dev/null | sort -h'
    ;;
  ol:7:2)
    run_check 'Check 1' 'df -i /var'
    run_check 'Check 2' 'find /var -xdev -type f | wc -l'
    run_check 'Check 3' 'du -xhd1 /var 2>/dev/null | sort -h'
    ;;
  ol:8:2)
    run_check 'Check 1' 'df -i /var'
    run_check 'Check 2' 'find /var -xdev -type f | wc -l'
    run_check 'Check 3' 'du -xhd1 /var 2>/dev/null | sort -h'
    ;;
  ol:9:2)
    run_check 'Check 1' 'df -i /var'
    run_check 'Check 2' 'find /var -xdev -type f | wc -l'
    run_check 'Check 3' 'du -xhd1 /var 2>/dev/null | sort -h'
    ;;
  rhel:7:2)
    run_check 'Check 1' 'df -i /var'
    run_check 'Check 2' 'find /var -xdev -type f | wc -l'
    run_check 'Check 3' 'du -xhd1 /var 2>/dev/null | sort -h'
    ;;
  rhel:8:2)
    run_check 'Check 1' 'df -i /var'
    run_check 'Check 2' 'find /var -xdev -type f | wc -l'
    run_check 'Check 3' 'du -xhd1 /var 2>/dev/null | sort -h'
    ;;
  rhel:9:2)
    run_check 'Check 1' 'df -i /var'
    run_check 'Check 2' 'find /var -xdev -type f | wc -l'
    run_check 'Check 3' 'du -xhd1 /var 2>/dev/null | sort -h'
    ;;
  ubuntu:20:3)
    run_check 'Check 1' 'du -sh /var/log/* 2>/dev/null | sort -h | tail'
    run_check 'Check 2' 'journalctl --disk-usage'
    run_check 'Check 3' 'ls -l /etc/logrotate.d/ | head'
    ;;
  ubuntu:22:3)
    run_check 'Check 1' 'du -sh /var/log/* 2>/dev/null | sort -h | tail'
    run_check 'Check 2' 'journalctl --disk-usage'
    run_check 'Check 3' 'ls -l /etc/logrotate.d/ | head'
    ;;
  ubuntu:24:3)
    run_check 'Check 1' 'du -sh /var/log/* 2>/dev/null | sort -h | tail'
    run_check 'Check 2' 'journalctl --disk-usage'
    run_check 'Check 3' 'ls -l /etc/logrotate.d/ | head'
    ;;
  ol:7:3)
    run_check 'Check 1' 'du -sh /var/log/* 2>/dev/null | sort -h | tail'
    run_check 'Check 2' 'journalctl --disk-usage'
    run_check 'Check 3' 'ls -l /etc/logrotate.d/ | head'
    ;;
  ol:8:3)
    run_check 'Check 1' 'du -sh /var/log/* 2>/dev/null | sort -h | tail'
    run_check 'Check 2' 'journalctl --disk-usage'
    run_check 'Check 3' 'ls -l /etc/logrotate.d/ | head'
    ;;
  ol:9:3)
    run_check 'Check 1' 'du -sh /var/log/* 2>/dev/null | sort -h | tail'
    run_check 'Check 2' 'journalctl --disk-usage'
    run_check 'Check 3' 'ls -l /etc/logrotate.d/ | head'
    ;;
  rhel:7:3)
    run_check 'Check 1' 'du -sh /var/log/* 2>/dev/null | sort -h | tail'
    run_check 'Check 2' 'journalctl --disk-usage'
    run_check 'Check 3' 'ls -l /etc/logrotate.d/ | head'
    ;;
  rhel:8:3)
    run_check 'Check 1' 'du -sh /var/log/* 2>/dev/null | sort -h | tail'
    run_check 'Check 2' 'journalctl --disk-usage'
    run_check 'Check 3' 'ls -l /etc/logrotate.d/ | head'
    ;;
  rhel:9:3)
    run_check 'Check 1' 'du -sh /var/log/* 2>/dev/null | sort -h | tail'
    run_check 'Check 2' 'journalctl --disk-usage'
    run_check 'Check 3' 'ls -l /etc/logrotate.d/ | head'
    ;;
  ubuntu:20:4)
    run_check 'Check 1' 'lsblk -o NAME,TYPE,SIZE,MODEL'
    run_check 'Check 2' 'sudo echo "Device placeholder: choose an actual disk first" 2>/dev/null'
    run_check 'Check 3' 'journalctl -k -b --no-pager | grep -Ei "I/O error|reset" | tail'
    ;;
  ubuntu:22:4)
    run_check 'Check 1' 'lsblk -o NAME,TYPE,SIZE,MODEL'
    run_check 'Check 2' 'sudo echo "Device placeholder: choose an actual disk first" 2>/dev/null'
    run_check 'Check 3' 'journalctl -k -b --no-pager | grep -Ei "I/O error|reset" | tail'
    ;;
  ubuntu:24:4)
    run_check 'Check 1' 'lsblk -o NAME,TYPE,SIZE,MODEL'
    run_check 'Check 2' 'sudo echo "Device placeholder: choose an actual disk first" 2>/dev/null'
    run_check 'Check 3' 'journalctl -k -b --no-pager | grep -Ei "I/O error|reset" | tail'
    ;;
  ol:7:4)
    run_check 'Check 1' 'lsblk -o NAME,TYPE,SIZE,MODEL'
    run_check 'Check 2' 'sudo echo "Device placeholder: choose an actual disk first" 2>/dev/null'
    run_check 'Check 3' 'journalctl -k -b --no-pager | grep -Ei "I/O error|reset" | tail'
    ;;
  ol:8:4)
    run_check 'Check 1' 'lsblk -o NAME,TYPE,SIZE,MODEL'
    run_check 'Check 2' 'sudo echo "Device placeholder: choose an actual disk first" 2>/dev/null'
    run_check 'Check 3' 'journalctl -k -b --no-pager | grep -Ei "I/O error|reset" | tail'
    ;;
  ol:9:4)
    run_check 'Check 1' 'lsblk -o NAME,TYPE,SIZE,MODEL'
    run_check 'Check 2' 'sudo echo "Device placeholder: choose an actual disk first" 2>/dev/null'
    run_check 'Check 3' 'journalctl -k -b --no-pager | grep -Ei "I/O error|reset" | tail'
    ;;
  rhel:7:4)
    run_check 'Check 1' 'lsblk -o NAME,TYPE,SIZE,MODEL'
    run_check 'Check 2' 'sudo echo "Device placeholder: choose an actual disk first" 2>/dev/null'
    run_check 'Check 3' 'journalctl -k -b --no-pager | grep -Ei "I/O error|reset" | tail'
    ;;
  rhel:8:4)
    run_check 'Check 1' 'lsblk -o NAME,TYPE,SIZE,MODEL'
    run_check 'Check 2' 'sudo echo "Device placeholder: choose an actual disk first" 2>/dev/null'
    run_check 'Check 3' 'journalctl -k -b --no-pager | grep -Ei "I/O error|reset" | tail'
    ;;
  rhel:9:4)
    run_check 'Check 1' 'lsblk -o NAME,TYPE,SIZE,MODEL'
    run_check 'Check 2' 'sudo echo "Device placeholder: choose an actual disk first" 2>/dev/null'
    run_check 'Check 3' 'journalctl -k -b --no-pager | grep -Ei "I/O error|reset" | tail'
    ;;
  ubuntu:20:5)
    run_check 'Check 1' 'lsblk -f'
    run_check 'Check 2' 'pvs; vgs; lvs -a -o +devices'
    run_check 'Check 3' 'df -hT'
    ;;
  ubuntu:22:5)
    run_check 'Check 1' 'lsblk -f'
    run_check 'Check 2' 'pvs; vgs; lvs -a -o +devices'
    run_check 'Check 3' 'df -hT'
    ;;
  ubuntu:24:5)
    run_check 'Check 1' 'lsblk -f'
    run_check 'Check 2' 'pvs; vgs; lvs -a -o +devices'
    run_check 'Check 3' 'df -hT'
    ;;
  ol:7:5)
    run_check 'Check 1' 'lsblk -f'
    run_check 'Check 2' 'pvs; vgs; lvs -a -o +devices'
    run_check 'Check 3' 'df -hT'
    ;;
  ol:8:5)
    run_check 'Check 1' 'lsblk -f'
    run_check 'Check 2' 'pvs; vgs; lvs -a -o +devices'
    run_check 'Check 3' 'df -hT'
    ;;
  ol:9:5)
    run_check 'Check 1' 'lsblk -f'
    run_check 'Check 2' 'pvs; vgs; lvs -a -o +devices'
    run_check 'Check 3' 'df -hT'
    ;;
  rhel:7:5)
    run_check 'Check 1' 'lsblk -f'
    run_check 'Check 2' 'pvs; vgs; lvs -a -o +devices'
    run_check 'Check 3' 'df -hT'
    ;;
  rhel:8:5)
    run_check 'Check 1' 'lsblk -f'
    run_check 'Check 2' 'pvs; vgs; lvs -a -o +devices'
    run_check 'Check 3' 'df -hT'
    ;;
  rhel:9:5)
    run_check 'Check 1' 'lsblk -f'
    run_check 'Check 2' 'pvs; vgs; lvs -a -o +devices'
    run_check 'Check 3' 'df -hT'
    ;;
  ubuntu:20:6)
    run_check 'Check 1' 'findmnt -no SOURCE,FSTYPE,OPTIONS /'
    run_check 'Check 2' 'journalctl -k -b -p warning --no-pager | tail -40'
    run_check 'Check 3' 'dmesg -T 2>/dev/null | tail -50'
    ;;
  ubuntu:22:6)
    run_check 'Check 1' 'findmnt -no SOURCE,FSTYPE,OPTIONS /'
    run_check 'Check 2' 'journalctl -k -b -p warning --no-pager | tail -40'
    run_check 'Check 3' 'dmesg -T 2>/dev/null | tail -50'
    ;;
  ubuntu:24:6)
    run_check 'Check 1' 'findmnt -no SOURCE,FSTYPE,OPTIONS /'
    run_check 'Check 2' 'journalctl -k -b -p warning --no-pager | tail -40'
    run_check 'Check 3' 'dmesg -T 2>/dev/null | tail -50'
    ;;
  ol:7:6)
    run_check 'Check 1' 'findmnt -no SOURCE,FSTYPE,OPTIONS /'
    run_check 'Check 2' 'journalctl -k -b -p warning --no-pager | tail -40'
    run_check 'Check 3' 'dmesg -T 2>/dev/null | tail -50'
    ;;
  ol:8:6)
    run_check 'Check 1' 'findmnt -no SOURCE,FSTYPE,OPTIONS /'
    run_check 'Check 2' 'journalctl -k -b -p warning --no-pager | tail -40'
    run_check 'Check 3' 'dmesg -T 2>/dev/null | tail -50'
    ;;
  ol:9:6)
    run_check 'Check 1' 'findmnt -no SOURCE,FSTYPE,OPTIONS /'
    run_check 'Check 2' 'journalctl -k -b -p warning --no-pager | tail -40'
    run_check 'Check 3' 'dmesg -T 2>/dev/null | tail -50'
    ;;
  rhel:7:6)
    run_check 'Check 1' 'findmnt -no SOURCE,FSTYPE,OPTIONS /'
    run_check 'Check 2' 'journalctl -k -b -p warning --no-pager | tail -40'
    run_check 'Check 3' 'dmesg -T 2>/dev/null | tail -50'
    ;;
  rhel:8:6)
    run_check 'Check 1' 'findmnt -no SOURCE,FSTYPE,OPTIONS /'
    run_check 'Check 2' 'journalctl -k -b -p warning --no-pager | tail -40'
    run_check 'Check 3' 'dmesg -T 2>/dev/null | tail -50'
    ;;
  rhel:9:6)
    run_check 'Check 1' 'findmnt -no SOURCE,FSTYPE,OPTIONS /'
    run_check 'Check 2' 'journalctl -k -b -p warning --no-pager | tail -40'
    run_check 'Check 3' 'dmesg -T 2>/dev/null | tail -50'
    ;;
  ubuntu:20:7)
    run_check 'Check 1' 'free -h'
    run_check 'Check 2' 'grep -E "MemAvailable|SwapTotal|SwapFree" /proc/meminfo'
    run_check 'Check 3' 'vmstat 1 3'
    ;;
  ubuntu:22:7)
    run_check 'Check 1' 'free -h'
    run_check 'Check 2' 'grep -E "MemAvailable|SwapTotal|SwapFree" /proc/meminfo'
    run_check 'Check 3' 'vmstat 1 3'
    ;;
  ubuntu:24:7)
    run_check 'Check 1' 'free -h'
    run_check 'Check 2' 'grep -E "MemAvailable|SwapTotal|SwapFree" /proc/meminfo'
    run_check 'Check 3' 'vmstat 1 3'
    ;;
  ol:7:7)
    run_check 'Check 1' 'free -h'
    run_check 'Check 2' 'grep -E "MemAvailable|SwapTotal|SwapFree" /proc/meminfo'
    run_check 'Check 3' 'vmstat 1 3'
    ;;
  ol:8:7)
    run_check 'Check 1' 'free -h'
    run_check 'Check 2' 'grep -E "MemAvailable|SwapTotal|SwapFree" /proc/meminfo'
    run_check 'Check 3' 'vmstat 1 3'
    ;;
  ol:9:7)
    run_check 'Check 1' 'free -h'
    run_check 'Check 2' 'grep -E "MemAvailable|SwapTotal|SwapFree" /proc/meminfo'
    run_check 'Check 3' 'vmstat 1 3'
    ;;
  rhel:7:7)
    run_check 'Check 1' 'free -h'
    run_check 'Check 2' 'grep -E "MemAvailable|SwapTotal|SwapFree" /proc/meminfo'
    run_check 'Check 3' 'vmstat 1 3'
    ;;
  rhel:8:7)
    run_check 'Check 1' 'free -h'
    run_check 'Check 2' 'grep -E "MemAvailable|SwapTotal|SwapFree" /proc/meminfo'
    run_check 'Check 3' 'vmstat 1 3'
    ;;
  rhel:9:7)
    run_check 'Check 1' 'free -h'
    run_check 'Check 2' 'grep -E "MemAvailable|SwapTotal|SwapFree" /proc/meminfo'
    run_check 'Check 3' 'vmstat 1 3'
    ;;
  ubuntu:20:8)
    run_check 'Check 1' 'journalctl -k -b --no-pager | grep -i "out of memory" | tail'
    run_check 'Check 2' 'journalctl -k -b --no-pager | grep -Ei "killed process|oom" | tail'
    run_check 'Check 3' 'free -h; systemctl --failed'
    ;;
  ubuntu:22:8)
    run_check 'Check 1' 'journalctl -k -b --no-pager | grep -i "out of memory" | tail'
    run_check 'Check 2' 'journalctl -k -b --no-pager | grep -Ei "killed process|oom" | tail'
    run_check 'Check 3' 'free -h; systemctl --failed'
    ;;
  ubuntu:24:8)
    run_check 'Check 1' 'journalctl -k -b --no-pager | grep -i "out of memory" | tail'
    run_check 'Check 2' 'journalctl -k -b --no-pager | grep -Ei "killed process|oom" | tail'
    run_check 'Check 3' 'free -h; systemctl --failed'
    ;;
  ol:7:8)
    run_check 'Check 1' 'journalctl -k -b --no-pager | grep -i "out of memory" | tail'
    run_check 'Check 2' 'journalctl -k -b --no-pager | grep -Ei "killed process|oom" | tail'
    run_check 'Check 3' 'free -h; systemctl --failed'
    ;;
  ol:8:8)
    run_check 'Check 1' 'journalctl -k -b --no-pager | grep -i "out of memory" | tail'
    run_check 'Check 2' 'journalctl -k -b --no-pager | grep -Ei "killed process|oom" | tail'
    run_check 'Check 3' 'free -h; systemctl --failed'
    ;;
  ol:9:8)
    run_check 'Check 1' 'journalctl -k -b --no-pager | grep -i "out of memory" | tail'
    run_check 'Check 2' 'journalctl -k -b --no-pager | grep -Ei "killed process|oom" | tail'
    run_check 'Check 3' 'free -h; systemctl --failed'
    ;;
  rhel:7:8)
    run_check 'Check 1' 'journalctl -k -b --no-pager | grep -i "out of memory" | tail'
    run_check 'Check 2' 'journalctl -k -b --no-pager | grep -Ei "killed process|oom" | tail'
    run_check 'Check 3' 'free -h; systemctl --failed'
    ;;
  rhel:8:8)
    run_check 'Check 1' 'journalctl -k -b --no-pager | grep -i "out of memory" | tail'
    run_check 'Check 2' 'journalctl -k -b --no-pager | grep -Ei "killed process|oom" | tail'
    run_check 'Check 3' 'free -h; systemctl --failed'
    ;;
  rhel:9:8)
    run_check 'Check 1' 'journalctl -k -b --no-pager | grep -i "out of memory" | tail'
    run_check 'Check 2' 'journalctl -k -b --no-pager | grep -Ei "killed process|oom" | tail'
    run_check 'Check 3' 'free -h; systemctl --failed'
    ;;
  ubuntu:20:9)
    run_check 'Check 1' 'swapon --show'
    run_check 'Check 2' 'vmstat 1 5'
    run_check 'Check 3' 'free -h; cat /proc/pressure/memory 2>/dev/null'
    ;;
  ubuntu:22:9)
    run_check 'Check 1' 'swapon --show'
    run_check 'Check 2' 'vmstat 1 5'
    run_check 'Check 3' 'free -h; cat /proc/pressure/memory 2>/dev/null'
    ;;
  ubuntu:24:9)
    run_check 'Check 1' 'swapon --show'
    run_check 'Check 2' 'vmstat 1 5'
    run_check 'Check 3' 'free -h; cat /proc/pressure/memory 2>/dev/null'
    ;;
  ol:7:9)
    run_check 'Check 1' 'swapon --show'
    run_check 'Check 2' 'vmstat 1 5'
    run_check 'Check 3' 'free -h; cat /proc/pressure/memory 2>/dev/null'
    ;;
  ol:8:9)
    run_check 'Check 1' 'swapon --show'
    run_check 'Check 2' 'vmstat 1 5'
    run_check 'Check 3' 'free -h; cat /proc/pressure/memory 2>/dev/null'
    ;;
  ol:9:9)
    run_check 'Check 1' 'swapon --show'
    run_check 'Check 2' 'vmstat 1 5'
    run_check 'Check 3' 'free -h; cat /proc/pressure/memory 2>/dev/null'
    ;;
  rhel:7:9)
    run_check 'Check 1' 'swapon --show'
    run_check 'Check 2' 'vmstat 1 5'
    run_check 'Check 3' 'free -h; cat /proc/pressure/memory 2>/dev/null'
    ;;
  rhel:8:9)
    run_check 'Check 1' 'swapon --show'
    run_check 'Check 2' 'vmstat 1 5'
    run_check 'Check 3' 'free -h; cat /proc/pressure/memory 2>/dev/null'
    ;;
  rhel:9:9)
    run_check 'Check 1' 'swapon --show'
    run_check 'Check 2' 'vmstat 1 5'
    run_check 'Check 3' 'free -h; cat /proc/pressure/memory 2>/dev/null'
    ;;
  ubuntu:20:10)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'ps -eo pid,comm,%cpu --sort=-%cpu | head'
    run_check 'Check 3' 'top -b -n 1 | head -20'
    ;;
  ubuntu:22:10)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'ps -eo pid,comm,%cpu --sort=-%cpu | head'
    run_check 'Check 3' 'top -b -n 1 | head -20'
    ;;
  ubuntu:24:10)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'ps -eo pid,comm,%cpu --sort=-%cpu | head'
    run_check 'Check 3' 'top -b -n 1 | head -20'
    ;;
  ol:7:10)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'ps -eo pid,comm,%cpu --sort=-%cpu | head'
    run_check 'Check 3' 'top -b -n 1 | head -20'
    ;;
  ol:8:10)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'ps -eo pid,comm,%cpu --sort=-%cpu | head'
    run_check 'Check 3' 'top -b -n 1 | head -20'
    ;;
  ol:9:10)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'ps -eo pid,comm,%cpu --sort=-%cpu | head'
    run_check 'Check 3' 'top -b -n 1 | head -20'
    ;;
  rhel:7:10)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'ps -eo pid,comm,%cpu --sort=-%cpu | head'
    run_check 'Check 3' 'top -b -n 1 | head -20'
    ;;
  rhel:8:10)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'ps -eo pid,comm,%cpu --sort=-%cpu | head'
    run_check 'Check 3' 'top -b -n 1 | head -20'
    ;;
  rhel:9:10)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'ps -eo pid,comm,%cpu --sort=-%cpu | head'
    run_check 'Check 3' 'top -b -n 1 | head -20'
    ;;
  ubuntu:20:11)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'vmstat 1 5'
    run_check 'Check 3' 'ps -eo state,pid,comm,wchan:24 | grep "^D" | head'
    ;;
  ubuntu:22:11)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'vmstat 1 5'
    run_check 'Check 3' 'ps -eo state,pid,comm,wchan:24 | grep "^D" | head'
    ;;
  ubuntu:24:11)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'vmstat 1 5'
    run_check 'Check 3' 'ps -eo state,pid,comm,wchan:24 | grep "^D" | head'
    ;;
  ol:7:11)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'vmstat 1 5'
    run_check 'Check 3' 'ps -eo state,pid,comm,wchan:24 | grep "^D" | head'
    ;;
  ol:8:11)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'vmstat 1 5'
    run_check 'Check 3' 'ps -eo state,pid,comm,wchan:24 | grep "^D" | head'
    ;;
  ol:9:11)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'vmstat 1 5'
    run_check 'Check 3' 'ps -eo state,pid,comm,wchan:24 | grep "^D" | head'
    ;;
  rhel:7:11)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'vmstat 1 5'
    run_check 'Check 3' 'ps -eo state,pid,comm,wchan:24 | grep "^D" | head'
    ;;
  rhel:8:11)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'vmstat 1 5'
    run_check 'Check 3' 'ps -eo state,pid,comm,wchan:24 | grep "^D" | head'
    ;;
  rhel:9:11)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'vmstat 1 5'
    run_check 'Check 3' 'ps -eo state,pid,comm,wchan:24 | grep "^D" | head'
    ;;
  ubuntu:20:12)
    run_check 'Check 1' 'iostat -xz 1 2 2>/dev/null'
    run_check 'Check 2' 'vmstat 1 3'
    run_check 'Check 3' 'dpkg-query -W sysstat 2>/dev/null'
    ;;
  ubuntu:22:12)
    run_check 'Check 1' 'iostat -xz 1 2 2>/dev/null'
    run_check 'Check 2' 'vmstat 1 3'
    run_check 'Check 3' 'dpkg-query -W sysstat 2>/dev/null'
    ;;
  ubuntu:24:12)
    run_check 'Check 1' 'iostat -xz 1 2 2>/dev/null'
    run_check 'Check 2' 'vmstat 1 3'
    run_check 'Check 3' 'dpkg-query -W sysstat 2>/dev/null'
    ;;
  ol:7:12)
    run_check 'Check 1' 'iostat -xz 1 2 2>/dev/null'
    run_check 'Check 2' 'vmstat 1 3'
    run_check 'Check 3' 'rpm -q sysstat'
    ;;
  ol:8:12)
    run_check 'Check 1' 'iostat -xz 1 2 2>/dev/null'
    run_check 'Check 2' 'vmstat 1 3'
    run_check 'Check 3' 'rpm -q sysstat'
    ;;
  ol:9:12)
    run_check 'Check 1' 'iostat -xz 1 2 2>/dev/null'
    run_check 'Check 2' 'vmstat 1 3'
    run_check 'Check 3' 'rpm -q sysstat'
    ;;
  rhel:7:12)
    run_check 'Check 1' 'iostat -xz 1 2 2>/dev/null'
    run_check 'Check 2' 'vmstat 1 3'
    run_check 'Check 3' 'rpm -q sysstat'
    ;;
  rhel:8:12)
    run_check 'Check 1' 'iostat -xz 1 2 2>/dev/null'
    run_check 'Check 2' 'vmstat 1 3'
    run_check 'Check 3' 'rpm -q sysstat'
    ;;
  rhel:9:12)
    run_check 'Check 1' 'iostat -xz 1 2 2>/dev/null'
    run_check 'Check 2' 'vmstat 1 3'
    run_check 'Check 3' 'rpm -q sysstat'
    ;;
  ubuntu:20:13)
    run_check 'Check 1' 'systemctl status ssh --no-pager'
    run_check 'Check 2' 'journalctl -u ssh -b -n 40 --no-pager'
    run_check 'Check 3' 'systemctl --failed'
    ;;
  ubuntu:22:13)
    run_check 'Check 1' 'systemctl status ssh --no-pager'
    run_check 'Check 2' 'journalctl -u ssh -b -n 40 --no-pager'
    run_check 'Check 3' 'systemctl --failed'
    ;;
  ubuntu:24:13)
    run_check 'Check 1' 'systemctl status ssh --no-pager'
    run_check 'Check 2' 'journalctl -u ssh -b -n 40 --no-pager'
    run_check 'Check 3' 'systemctl --failed'
    ;;
  ol:7:13)
    run_check 'Check 1' 'systemctl status sshd --no-pager'
    run_check 'Check 2' 'journalctl -u sshd -b -n 40 --no-pager'
    run_check 'Check 3' 'systemctl --failed'
    ;;
  ol:8:13)
    run_check 'Check 1' 'systemctl status sshd --no-pager'
    run_check 'Check 2' 'journalctl -u sshd -b -n 40 --no-pager'
    run_check 'Check 3' 'systemctl --failed'
    ;;
  ol:9:13)
    run_check 'Check 1' 'systemctl status sshd --no-pager'
    run_check 'Check 2' 'journalctl -u sshd -b -n 40 --no-pager'
    run_check 'Check 3' 'systemctl --failed'
    ;;
  rhel:7:13)
    run_check 'Check 1' 'systemctl status sshd --no-pager'
    run_check 'Check 2' 'journalctl -u sshd -b -n 40 --no-pager'
    run_check 'Check 3' 'systemctl --failed'
    ;;
  rhel:8:13)
    run_check 'Check 1' 'systemctl status sshd --no-pager'
    run_check 'Check 2' 'journalctl -u sshd -b -n 40 --no-pager'
    run_check 'Check 3' 'systemctl --failed'
    ;;
  rhel:9:13)
    run_check 'Check 1' 'systemctl status sshd --no-pager'
    run_check 'Check 2' 'journalctl -u sshd -b -n 40 --no-pager'
    run_check 'Check 3' 'systemctl --failed'
    ;;
  ubuntu:20:14)
    run_check 'Check 1' 'systemctl show ssh -p NRestarts -p Result'
    run_check 'Check 2' 'journalctl -u ssh -b -n 35 --no-pager'
    run_check 'Check 3' 'systemctl cat ssh'
    ;;
  ubuntu:22:14)
    run_check 'Check 1' 'systemctl show ssh -p NRestarts -p Result'
    run_check 'Check 2' 'journalctl -u ssh -b -n 35 --no-pager'
    run_check 'Check 3' 'systemctl cat ssh'
    ;;
  ubuntu:24:14)
    run_check 'Check 1' 'systemctl show ssh -p NRestarts -p Result'
    run_check 'Check 2' 'journalctl -u ssh -b -n 35 --no-pager'
    run_check 'Check 3' 'systemctl cat ssh'
    ;;
  ol:7:14)
    run_check 'Check 1' 'systemctl show sshd -p NRestarts -p Result'
    run_check 'Check 2' 'journalctl -u sshd -b -n 35 --no-pager'
    run_check 'Check 3' 'systemctl cat sshd'
    ;;
  ol:8:14)
    run_check 'Check 1' 'systemctl show sshd -p NRestarts -p Result'
    run_check 'Check 2' 'journalctl -u sshd -b -n 35 --no-pager'
    run_check 'Check 3' 'systemctl cat sshd'
    ;;
  ol:9:14)
    run_check 'Check 1' 'systemctl show sshd -p NRestarts -p Result'
    run_check 'Check 2' 'journalctl -u sshd -b -n 35 --no-pager'
    run_check 'Check 3' 'systemctl cat sshd'
    ;;
  rhel:7:14)
    run_check 'Check 1' 'systemctl show sshd -p NRestarts -p Result'
    run_check 'Check 2' 'journalctl -u sshd -b -n 35 --no-pager'
    run_check 'Check 3' 'systemctl cat sshd'
    ;;
  rhel:8:14)
    run_check 'Check 1' 'systemctl show sshd -p NRestarts -p Result'
    run_check 'Check 2' 'journalctl -u sshd -b -n 35 --no-pager'
    run_check 'Check 3' 'systemctl cat sshd'
    ;;
  rhel:9:14)
    run_check 'Check 1' 'systemctl show sshd -p NRestarts -p Result'
    run_check 'Check 2' 'journalctl -u sshd -b -n 35 --no-pager'
    run_check 'Check 3' 'systemctl cat sshd'
    ;;
  ubuntu:20:15)
    run_check 'Check 1' 'journalctl --disk-usage'
    run_check 'Check 2' 'journalctl -p warning -b --no-pager | tail -35'
    run_check 'Check 3' 'grep -v "^#" /etc/systemd/journald.conf | head'
    ;;
  ubuntu:22:15)
    run_check 'Check 1' 'journalctl --disk-usage'
    run_check 'Check 2' 'journalctl -p warning -b --no-pager | tail -35'
    run_check 'Check 3' 'grep -v "^#" /etc/systemd/journald.conf | head'
    ;;
  ubuntu:24:15)
    run_check 'Check 1' 'journalctl --disk-usage'
    run_check 'Check 2' 'journalctl -p warning -b --no-pager | tail -35'
    run_check 'Check 3' 'grep -v "^#" /etc/systemd/journald.conf | head'
    ;;
  ol:7:15)
    run_check 'Check 1' 'journalctl --disk-usage'
    run_check 'Check 2' 'journalctl -p warning -b --no-pager | tail -35'
    run_check 'Check 3' 'grep -v "^#" /etc/systemd/journald.conf | head'
    ;;
  ol:8:15)
    run_check 'Check 1' 'journalctl --disk-usage'
    run_check 'Check 2' 'journalctl -p warning -b --no-pager | tail -35'
    run_check 'Check 3' 'grep -v "^#" /etc/systemd/journald.conf | head'
    ;;
  ol:9:15)
    run_check 'Check 1' 'journalctl --disk-usage'
    run_check 'Check 2' 'journalctl -p warning -b --no-pager | tail -35'
    run_check 'Check 3' 'grep -v "^#" /etc/systemd/journald.conf | head'
    ;;
  rhel:7:15)
    run_check 'Check 1' 'journalctl --disk-usage'
    run_check 'Check 2' 'journalctl -p warning -b --no-pager | tail -35'
    run_check 'Check 3' 'grep -v "^#" /etc/systemd/journald.conf | head'
    ;;
  rhel:8:15)
    run_check 'Check 1' 'journalctl --disk-usage'
    run_check 'Check 2' 'journalctl -p warning -b --no-pager | tail -35'
    run_check 'Check 3' 'grep -v "^#" /etc/systemd/journald.conf | head'
    ;;
  rhel:9:15)
    run_check 'Check 1' 'journalctl --disk-usage'
    run_check 'Check 2' 'journalctl -p warning -b --no-pager | tail -35'
    run_check 'Check 3' 'grep -v "^#" /etc/systemd/journald.conf | head'
    ;;
  ubuntu:20:16)
    run_check 'Check 1' 'logrotate -d /etc/logrotate.conf 2>&1 | tail -25'
    run_check 'Check 2' 'systemctl list-timers --all | grep -i logrotate'
    run_check 'Check 3' 'cat /etc/logrotate.conf | head -30'
    ;;
  ubuntu:22:16)
    run_check 'Check 1' 'logrotate -d /etc/logrotate.conf 2>&1 | tail -25'
    run_check 'Check 2' 'systemctl list-timers --all | grep -i logrotate'
    run_check 'Check 3' 'cat /etc/logrotate.conf | head -30'
    ;;
  ubuntu:24:16)
    run_check 'Check 1' 'logrotate -d /etc/logrotate.conf 2>&1 | tail -25'
    run_check 'Check 2' 'systemctl list-timers --all | grep -i logrotate'
    run_check 'Check 3' 'cat /etc/logrotate.conf | head -30'
    ;;
  ol:7:16)
    run_check 'Check 1' 'logrotate -d /etc/logrotate.conf 2>&1 | tail -25'
    run_check 'Check 2' 'systemctl status crond --no-pager'
    run_check 'Check 3' 'ls -l /etc/cron.daily/logrotate 2>/dev/null'
    ;;
  ol:8:16)
    run_check 'Check 1' 'logrotate -d /etc/logrotate.conf 2>&1 | tail -25'
    run_check 'Check 2' 'systemctl status crond --no-pager'
    run_check 'Check 3' 'ls -l /etc/cron.daily/logrotate 2>/dev/null'
    ;;
  ol:9:16)
    run_check 'Check 1' 'logrotate -d /etc/logrotate.conf 2>&1 | tail -25'
    run_check 'Check 2' 'systemctl status crond --no-pager'
    run_check 'Check 3' 'ls -l /etc/cron.daily/logrotate 2>/dev/null'
    ;;
  rhel:7:16)
    run_check 'Check 1' 'logrotate -d /etc/logrotate.conf 2>&1 | tail -25'
    run_check 'Check 2' 'systemctl status crond --no-pager'
    run_check 'Check 3' 'ls -l /etc/cron.daily/logrotate 2>/dev/null'
    ;;
  rhel:8:16)
    run_check 'Check 1' 'logrotate -d /etc/logrotate.conf 2>&1 | tail -25'
    run_check 'Check 2' 'systemctl status crond --no-pager'
    run_check 'Check 3' 'ls -l /etc/cron.daily/logrotate 2>/dev/null'
    ;;
  rhel:9:16)
    run_check 'Check 1' 'logrotate -d /etc/logrotate.conf 2>&1 | tail -25'
    run_check 'Check 2' 'systemctl status crond --no-pager'
    run_check 'Check 3' 'ls -l /etc/cron.daily/logrotate 2>/dev/null'
    ;;
  ubuntu:20:17)
    run_check 'Check 1' 'systemctl status cron --no-pager'
    run_check 'Check 2' 'systemctl list-timers --all | head -20'
    run_check 'Check 3' 'journalctl -u cron -b -n 25 --no-pager'
    ;;
  ubuntu:22:17)
    run_check 'Check 1' 'systemctl status cron --no-pager'
    run_check 'Check 2' 'systemctl list-timers --all | head -20'
    run_check 'Check 3' 'journalctl -u cron -b -n 25 --no-pager'
    ;;
  ubuntu:24:17)
    run_check 'Check 1' 'systemctl status cron --no-pager'
    run_check 'Check 2' 'systemctl list-timers --all | head -20'
    run_check 'Check 3' 'journalctl -u cron -b -n 25 --no-pager'
    ;;
  ol:7:17)
    run_check 'Check 1' 'systemctl status crond --no-pager'
    run_check 'Check 2' 'systemctl list-timers --all | head -20'
    run_check 'Check 3' 'journalctl -u crond -b -n 25 --no-pager'
    ;;
  ol:8:17)
    run_check 'Check 1' 'systemctl status crond --no-pager'
    run_check 'Check 2' 'systemctl list-timers --all | head -20'
    run_check 'Check 3' 'journalctl -u crond -b -n 25 --no-pager'
    ;;
  ol:9:17)
    run_check 'Check 1' 'systemctl status crond --no-pager'
    run_check 'Check 2' 'systemctl list-timers --all | head -20'
    run_check 'Check 3' 'journalctl -u crond -b -n 25 --no-pager'
    ;;
  rhel:7:17)
    run_check 'Check 1' 'systemctl status crond --no-pager'
    run_check 'Check 2' 'systemctl list-timers --all | head -20'
    run_check 'Check 3' 'journalctl -u crond -b -n 25 --no-pager'
    ;;
  rhel:8:17)
    run_check 'Check 1' 'systemctl status crond --no-pager'
    run_check 'Check 2' 'systemctl list-timers --all | head -20'
    run_check 'Check 3' 'journalctl -u crond -b -n 25 --no-pager'
    ;;
  rhel:9:17)
    run_check 'Check 1' 'systemctl status crond --no-pager'
    run_check 'Check 2' 'systemctl list-timers --all | head -20'
    run_check 'Check 3' 'journalctl -u crond -b -n 25 --no-pager'
    ;;
  ubuntu:20:18)
    run_check 'Check 1' 'systemd-analyze time'
    run_check 'Check 2' 'systemd-analyze blame | head -25'
    run_check 'Check 3' 'systemd-analyze critical-chain'
    ;;
  ubuntu:22:18)
    run_check 'Check 1' 'systemd-analyze time'
    run_check 'Check 2' 'systemd-analyze blame | head -25'
    run_check 'Check 3' 'systemd-analyze critical-chain'
    ;;
  ubuntu:24:18)
    run_check 'Check 1' 'systemd-analyze time'
    run_check 'Check 2' 'systemd-analyze blame | head -25'
    run_check 'Check 3' 'systemd-analyze critical-chain'
    ;;
  ol:7:18)
    run_check 'Check 1' 'systemd-analyze time'
    run_check 'Check 2' 'systemd-analyze blame | head -25'
    run_check 'Check 3' 'systemd-analyze critical-chain'
    ;;
  ol:8:18)
    run_check 'Check 1' 'systemd-analyze time'
    run_check 'Check 2' 'systemd-analyze blame | head -25'
    run_check 'Check 3' 'systemd-analyze critical-chain'
    ;;
  ol:9:18)
    run_check 'Check 1' 'systemd-analyze time'
    run_check 'Check 2' 'systemd-analyze blame | head -25'
    run_check 'Check 3' 'systemd-analyze critical-chain'
    ;;
  rhel:7:18)
    run_check 'Check 1' 'systemd-analyze time'
    run_check 'Check 2' 'systemd-analyze blame | head -25'
    run_check 'Check 3' 'systemd-analyze critical-chain'
    ;;
  rhel:8:18)
    run_check 'Check 1' 'systemd-analyze time'
    run_check 'Check 2' 'systemd-analyze blame | head -25'
    run_check 'Check 3' 'systemd-analyze critical-chain'
    ;;
  rhel:9:18)
    run_check 'Check 1' 'systemd-analyze time'
    run_check 'Check 2' 'systemd-analyze blame | head -25'
    run_check 'Check 3' 'systemd-analyze critical-chain'
    ;;
  ubuntu:20:19)
    run_check 'Check 1' 'apt-cache policy'
    run_check 'Check 2' 'getent hosts archive.ubuntu.com'
    run_check 'Check 3' 'grep -Rh "^deb " /etc/apt/sources.list /etc/apt/sources.list.d/ 2>/dev/null | head'
    ;;
  ubuntu:22:19)
    run_check 'Check 1' 'apt-cache policy'
    run_check 'Check 2' 'getent hosts archive.ubuntu.com'
    run_check 'Check 3' 'grep -Rh "^deb " /etc/apt/sources.list /etc/apt/sources.list.d/ 2>/dev/null | head'
    ;;
  ubuntu:24:19)
    run_check 'Check 1' 'apt-cache policy'
    run_check 'Check 2' 'getent hosts archive.ubuntu.com'
    run_check 'Check 3' 'grep -Rh "^deb " /etc/apt/sources.list /etc/apt/sources.list.d/ 2>/dev/null | head'
    ;;
  ol:7:19)
    run_check 'Check 1' 'yum repolist -v | head -35'
    run_check 'Check 2' 'yum makecache 2>&1 | tail -20'
    run_check 'Check 3' 'date -u; getent hosts example.com'
    ;;
  ol:8:19)
    run_check 'Check 1' 'dnf repolist -v | head -35'
    run_check 'Check 2' 'dnf makecache 2>&1 | tail -20'
    run_check 'Check 3' 'date -u; getent hosts example.com'
    ;;
  ol:9:19)
    run_check 'Check 1' 'dnf repolist -v | head -35'
    run_check 'Check 2' 'dnf makecache 2>&1 | tail -20'
    run_check 'Check 3' 'date -u; getent hosts example.com'
    ;;
  rhel:7:19)
    run_check 'Check 1' 'yum repolist -v | head -35'
    run_check 'Check 2' 'yum makecache 2>&1 | tail -20'
    run_check 'Check 3' 'date -u; getent hosts example.com'
    ;;
  rhel:8:19)
    run_check 'Check 1' 'dnf repolist -v | head -35'
    run_check 'Check 2' 'dnf makecache 2>&1 | tail -20'
    run_check 'Check 3' 'date -u; getent hosts example.com'
    ;;
  rhel:9:19)
    run_check 'Check 1' 'dnf repolist -v | head -35'
    run_check 'Check 2' 'dnf makecache 2>&1 | tail -20'
    run_check 'Check 3' 'date -u; getent hosts example.com'
    ;;
  ubuntu:20:20)
    run_check 'Check 1' 'ps -ef | grep -E "apt|dpkg" | grep -v grep'
    run_check 'Check 2' 'lslocks | grep -E "apt|dpkg"'
    run_check 'Check 3' 'systemctl list-timers | grep apt'
    ;;
  ubuntu:22:20)
    run_check 'Check 1' 'ps -ef | grep -E "apt|dpkg" | grep -v grep'
    run_check 'Check 2' 'lslocks | grep -E "apt|dpkg"'
    run_check 'Check 3' 'systemctl list-timers | grep apt'
    ;;
  ubuntu:24:20)
    run_check 'Check 1' 'ps -ef | grep -E "apt|dpkg" | grep -v grep'
    run_check 'Check 2' 'lslocks | grep -E "apt|dpkg"'
    run_check 'Check 3' 'systemctl list-timers | grep apt'
    ;;
  ol:7:20)
    run_check 'Check 1' 'ps -ef | grep -E "yum|dnf|rpm" | grep -v grep'
    run_check 'Check 2' 'yum history list | head'
    run_check 'Check 3' 'journalctl -b -p err --no-pager | tail -20'
    ;;
  ol:8:20)
    run_check 'Check 1' 'ps -ef | grep -E "yum|dnf|rpm" | grep -v grep'
    run_check 'Check 2' 'dnf history list | head'
    run_check 'Check 3' 'journalctl -b -p err --no-pager | tail -20'
    ;;
  ol:9:20)
    run_check 'Check 1' 'ps -ef | grep -E "yum|dnf|rpm" | grep -v grep'
    run_check 'Check 2' 'dnf history list | head'
    run_check 'Check 3' 'journalctl -b -p err --no-pager | tail -20'
    ;;
  rhel:7:20)
    run_check 'Check 1' 'ps -ef | grep -E "yum|dnf|rpm" | grep -v grep'
    run_check 'Check 2' 'yum history list | head'
    run_check 'Check 3' 'journalctl -b -p err --no-pager | tail -20'
    ;;
  rhel:8:20)
    run_check 'Check 1' 'ps -ef | grep -E "yum|dnf|rpm" | grep -v grep'
    run_check 'Check 2' 'dnf history list | head'
    run_check 'Check 3' 'journalctl -b -p err --no-pager | tail -20'
    ;;
  rhel:9:20)
    run_check 'Check 1' 'ps -ef | grep -E "yum|dnf|rpm" | grep -v grep'
    run_check 'Check 2' 'dnf history list | head'
    run_check 'Check 3' 'journalctl -b -p err --no-pager | tail -20'
    ;;
  ubuntu:20:21)
    run_check 'Check 1' 'apt-cache policy'
    run_check 'Check 2' 'apt-mark showhold'
    run_check 'Check 3' 'dpkg --audit'
    ;;
  ubuntu:22:21)
    run_check 'Check 1' 'apt-cache policy'
    run_check 'Check 2' 'apt-mark showhold'
    run_check 'Check 3' 'dpkg --audit'
    ;;
  ubuntu:24:21)
    run_check 'Check 1' 'apt-cache policy'
    run_check 'Check 2' 'apt-mark showhold'
    run_check 'Check 3' 'dpkg --audit'
    ;;
  ol:7:21)
    run_check 'Check 1' 'yum repolist'
    run_check 'Check 2' 'yum check 2>&1 | tail -20'
    run_check 'Check 3' 'rpm -qa | sort | tail -15'
    ;;
  ol:8:21)
    run_check 'Check 1' 'dnf repolist'
    run_check 'Check 2' 'dnf check 2>&1 | tail -20'
    run_check 'Check 3' 'rpm -qa | sort | tail -15'
    ;;
  ol:9:21)
    run_check 'Check 1' 'dnf repolist'
    run_check 'Check 2' 'dnf check 2>&1 | tail -20'
    run_check 'Check 3' 'rpm -qa | sort | tail -15'
    ;;
  rhel:7:21)
    run_check 'Check 1' 'yum repolist'
    run_check 'Check 2' 'yum check 2>&1 | tail -20'
    run_check 'Check 3' 'rpm -qa | sort | tail -15'
    ;;
  rhel:8:21)
    run_check 'Check 1' 'dnf repolist'
    run_check 'Check 2' 'dnf check 2>&1 | tail -20'
    run_check 'Check 3' 'rpm -qa | sort | tail -15'
    ;;
  rhel:9:21)
    run_check 'Check 1' 'dnf repolist'
    run_check 'Check 2' 'dnf check 2>&1 | tail -20'
    run_check 'Check 3' 'rpm -qa | sort | tail -15'
    ;;
  ubuntu:20:22)
    run_check 'Check 1' 'apt list --upgradable 2>/dev/null | head'
    run_check 'Check 2' 'apt-cache policy'
    run_check 'Check 3' 'uname -r'
    ;;
  ubuntu:22:22)
    run_check 'Check 1' 'apt list --upgradable 2>/dev/null | head'
    run_check 'Check 2' 'apt-cache policy'
    run_check 'Check 3' 'uname -r'
    ;;
  ubuntu:24:22)
    run_check 'Check 1' 'apt list --upgradable 2>/dev/null | head'
    run_check 'Check 2' 'apt-cache policy'
    run_check 'Check 3' 'uname -r'
    ;;
  ol:7:22)
    run_check 'Check 1' 'yum updateinfo list security 2>&1 | head -25'
    run_check 'Check 2' 'rpm -q kernel'
    run_check 'Check 3' 'uname -r'
    ;;
  ol:8:22)
    run_check 'Check 1' 'dnf updateinfo list security 2>&1 | head -25'
    run_check 'Check 2' 'rpm -q kernel'
    run_check 'Check 3' 'uname -r'
    ;;
  ol:9:22)
    run_check 'Check 1' 'dnf updateinfo list security 2>&1 | head -25'
    run_check 'Check 2' 'rpm -q kernel'
    run_check 'Check 3' 'uname -r'
    ;;
  rhel:7:22)
    run_check 'Check 1' 'yum updateinfo list security 2>&1 | head -25'
    run_check 'Check 2' 'rpm -q kernel'
    run_check 'Check 3' 'uname -r'
    ;;
  rhel:8:22)
    run_check 'Check 1' 'dnf updateinfo list security 2>&1 | head -25'
    run_check 'Check 2' 'rpm -q kernel'
    run_check 'Check 3' 'uname -r'
    ;;
  rhel:9:22)
    run_check 'Check 1' 'dnf updateinfo list security 2>&1 | head -25'
    run_check 'Check 2' 'rpm -q kernel'
    run_check 'Check 3' 'uname -r'
    ;;
  ubuntu:20:23)
    run_check 'Check 1' 'ip -brief link'
    run_check 'Check 2' 'ip -brief address'
    run_check 'Check 3' 'sudo netplan get 2>/dev/null | head -35'
    ;;
  ubuntu:22:23)
    run_check 'Check 1' 'ip -brief link'
    run_check 'Check 2' 'ip -brief address'
    run_check 'Check 3' 'sudo netplan get 2>/dev/null | head -35'
    ;;
  ubuntu:24:23)
    run_check 'Check 1' 'ip -brief link'
    run_check 'Check 2' 'ip -brief address'
    run_check 'Check 3' 'sudo netplan get 2>/dev/null | head -35'
    ;;
  ol:7:23)
    run_check 'Check 1' 'nmcli device status'
    run_check 'Check 2' 'ip -brief address'
    run_check 'Check 3' 'ip route'
    ;;
  ol:8:23)
    run_check 'Check 1' 'nmcli device status'
    run_check 'Check 2' 'ip -brief address'
    run_check 'Check 3' 'ip route'
    ;;
  ol:9:23)
    run_check 'Check 1' 'nmcli device status'
    run_check 'Check 2' 'ip -brief address'
    run_check 'Check 3' 'ip route'
    ;;
  rhel:7:23)
    run_check 'Check 1' 'nmcli device status'
    run_check 'Check 2' 'ip -brief address'
    run_check 'Check 3' 'ip route'
    ;;
  rhel:8:23)
    run_check 'Check 1' 'nmcli device status'
    run_check 'Check 2' 'ip -brief address'
    run_check 'Check 3' 'ip route'
    ;;
  rhel:9:23)
    run_check 'Check 1' 'nmcli device status'
    run_check 'Check 2' 'ip -brief address'
    run_check 'Check 3' 'ip route'
    ;;
  ubuntu:20:24)
    run_check 'Check 1' 'getent hosts example.com'
    run_check 'Check 2' 'systemd-resolve --status 2>/dev/null | head -30'
    run_check 'Check 3' 'readlink -f /etc/resolv.conf'
    ;;
  ubuntu:22:24)
    run_check 'Check 1' 'getent hosts example.com'
    run_check 'Check 2' 'resolvectl status 2>/dev/null | head -30'
    run_check 'Check 3' 'readlink -f /etc/resolv.conf'
    ;;
  ubuntu:24:24)
    run_check 'Check 1' 'getent hosts example.com'
    run_check 'Check 2' 'resolvectl status 2>/dev/null | head -30'
    run_check 'Check 3' 'readlink -f /etc/resolv.conf'
    ;;
  ol:7:24)
    run_check 'Check 1' 'getent hosts example.com'
    run_check 'Check 2' 'nmcli device show | grep -i dns | head'
    run_check 'Check 3' 'cat /etc/resolv.conf'
    ;;
  ol:8:24)
    run_check 'Check 1' 'getent hosts example.com'
    run_check 'Check 2' 'nmcli device show | grep -i dns | head'
    run_check 'Check 3' 'cat /etc/resolv.conf'
    ;;
  ol:9:24)
    run_check 'Check 1' 'getent hosts example.com'
    run_check 'Check 2' 'nmcli device show | grep -i dns | head'
    run_check 'Check 3' 'cat /etc/resolv.conf'
    ;;
  rhel:7:24)
    run_check 'Check 1' 'getent hosts example.com'
    run_check 'Check 2' 'nmcli device show | grep -i dns | head'
    run_check 'Check 3' 'cat /etc/resolv.conf'
    ;;
  rhel:8:24)
    run_check 'Check 1' 'getent hosts example.com'
    run_check 'Check 2' 'nmcli device show | grep -i dns | head'
    run_check 'Check 3' 'cat /etc/resolv.conf'
    ;;
  rhel:9:24)
    run_check 'Check 1' 'getent hosts example.com'
    run_check 'Check 2' 'nmcli device show | grep -i dns | head'
    run_check 'Check 3' 'cat /etc/resolv.conf'
    ;;
  ubuntu:20:25)
    run_check 'Check 1' 'ip route'
    run_check 'Check 2' 'ip rule'
    run_check 'Check 3' 'sudo netplan get 2>/dev/null | head -35'
    ;;
  ubuntu:22:25)
    run_check 'Check 1' 'ip route'
    run_check 'Check 2' 'ip rule'
    run_check 'Check 3' 'sudo netplan get 2>/dev/null | head -35'
    ;;
  ubuntu:24:25)
    run_check 'Check 1' 'ip route'
    run_check 'Check 2' 'ip rule'
    run_check 'Check 3' 'sudo netplan get 2>/dev/null | head -35'
    ;;
  ol:7:25)
    run_check 'Check 1' 'ip route'
    run_check 'Check 2' 'nmcli -g IP4.GATEWAY device show'
    run_check 'Check 3' 'ip rule show'
    ;;
  ol:8:25)
    run_check 'Check 1' 'ip route'
    run_check 'Check 2' 'nmcli -g IP4.GATEWAY device show'
    run_check 'Check 3' 'ip rule show'
    ;;
  ol:9:25)
    run_check 'Check 1' 'ip route'
    run_check 'Check 2' 'nmcli -g IP4.GATEWAY device show'
    run_check 'Check 3' 'ip rule show'
    ;;
  rhel:7:25)
    run_check 'Check 1' 'ip route'
    run_check 'Check 2' 'nmcli -g IP4.GATEWAY device show'
    run_check 'Check 3' 'ip rule show'
    ;;
  rhel:8:25)
    run_check 'Check 1' 'ip route'
    run_check 'Check 2' 'nmcli -g IP4.GATEWAY device show'
    run_check 'Check 3' 'ip rule show'
    ;;
  rhel:9:25)
    run_check 'Check 1' 'ip route'
    run_check 'Check 2' 'nmcli -g IP4.GATEWAY device show'
    run_check 'Check 3' 'ip rule show'
    ;;
  ubuntu:20:26)
    run_check 'Check 1' 'ss -lntp'
    run_check 'Check 2' 'systemctl --failed'
    run_check 'Check 3' 'curl -v --max-time 5 http://127.0.0.1:8080/ 2>&1 | tail'
    ;;
  ubuntu:22:26)
    run_check 'Check 1' 'ss -lntp'
    run_check 'Check 2' 'systemctl --failed'
    run_check 'Check 3' 'curl -v --max-time 5 http://127.0.0.1:8080/ 2>&1 | tail'
    ;;
  ubuntu:24:26)
    run_check 'Check 1' 'ss -lntp'
    run_check 'Check 2' 'systemctl --failed'
    run_check 'Check 3' 'curl -v --max-time 5 http://127.0.0.1:8080/ 2>&1 | tail'
    ;;
  ol:7:26)
    run_check 'Check 1' 'ss -lntp'
    run_check 'Check 2' 'systemctl --failed'
    run_check 'Check 3' 'curl -v --max-time 5 http://127.0.0.1:8080/ 2>&1 | tail'
    ;;
  ol:8:26)
    run_check 'Check 1' 'ss -lntp'
    run_check 'Check 2' 'systemctl --failed'
    run_check 'Check 3' 'curl -v --max-time 5 http://127.0.0.1:8080/ 2>&1 | tail'
    ;;
  ol:9:26)
    run_check 'Check 1' 'ss -lntp'
    run_check 'Check 2' 'systemctl --failed'
    run_check 'Check 3' 'curl -v --max-time 5 http://127.0.0.1:8080/ 2>&1 | tail'
    ;;
  rhel:7:26)
    run_check 'Check 1' 'ss -lntp'
    run_check 'Check 2' 'systemctl --failed'
    run_check 'Check 3' 'curl -v --max-time 5 http://127.0.0.1:8080/ 2>&1 | tail'
    ;;
  rhel:8:26)
    run_check 'Check 1' 'ss -lntp'
    run_check 'Check 2' 'systemctl --failed'
    run_check 'Check 3' 'curl -v --max-time 5 http://127.0.0.1:8080/ 2>&1 | tail'
    ;;
  rhel:9:26)
    run_check 'Check 1' 'ss -lntp'
    run_check 'Check 2' 'systemctl --failed'
    run_check 'Check 3' 'curl -v --max-time 5 http://127.0.0.1:8080/ 2>&1 | tail'
    ;;
  ubuntu:20:27)
    run_check 'Check 1' 'systemctl status ssh --no-pager'
    run_check 'Check 2' 'ss -lntp | grep :22'
    run_check 'Check 3' 'journalctl -u ssh -b -n 30 --no-pager'
    ;;
  ubuntu:22:27)
    run_check 'Check 1' 'systemctl status ssh --no-pager'
    run_check 'Check 2' 'ss -lntp | grep :22'
    run_check 'Check 3' 'journalctl -u ssh -b -n 30 --no-pager'
    ;;
  ubuntu:24:27)
    run_check 'Check 1' 'systemctl status ssh --no-pager'
    run_check 'Check 2' 'ss -lntp | grep :22'
    run_check 'Check 3' 'journalctl -u ssh -b -n 30 --no-pager'
    ;;
  ol:7:27)
    run_check 'Check 1' 'systemctl status sshd --no-pager'
    run_check 'Check 2' 'ss -lntp | grep :22'
    run_check 'Check 3' 'journalctl -u sshd -b -n 30 --no-pager'
    ;;
  ol:8:27)
    run_check 'Check 1' 'systemctl status sshd --no-pager'
    run_check 'Check 2' 'ss -lntp | grep :22'
    run_check 'Check 3' 'journalctl -u sshd -b -n 30 --no-pager'
    ;;
  ol:9:27)
    run_check 'Check 1' 'systemctl status sshd --no-pager'
    run_check 'Check 2' 'ss -lntp | grep :22'
    run_check 'Check 3' 'journalctl -u sshd -b -n 30 --no-pager'
    ;;
  rhel:7:27)
    run_check 'Check 1' 'systemctl status sshd --no-pager'
    run_check 'Check 2' 'ss -lntp | grep :22'
    run_check 'Check 3' 'journalctl -u sshd -b -n 30 --no-pager'
    ;;
  rhel:8:27)
    run_check 'Check 1' 'systemctl status sshd --no-pager'
    run_check 'Check 2' 'ss -lntp | grep :22'
    run_check 'Check 3' 'journalctl -u sshd -b -n 30 --no-pager'
    ;;
  rhel:9:27)
    run_check 'Check 1' 'systemctl status sshd --no-pager'
    run_check 'Check 2' 'ss -lntp | grep :22'
    run_check 'Check 3' 'journalctl -u sshd -b -n 30 --no-pager'
    ;;
  ubuntu:20:28)
    run_check 'Check 1' 'openssl version'
    run_check 'Check 2' 'date -u'
    run_check 'Check 3' 'openssl s_client -connect example.com:443 -servername example.com </dev/null 2>/dev/null | openssl x509 -noout -dates'
    ;;
  ubuntu:22:28)
    run_check 'Check 1' 'openssl version'
    run_check 'Check 2' 'date -u'
    run_check 'Check 3' 'openssl s_client -connect example.com:443 -servername example.com </dev/null 2>/dev/null | openssl x509 -noout -dates'
    ;;
  ubuntu:24:28)
    run_check 'Check 1' 'openssl version'
    run_check 'Check 2' 'date -u'
    run_check 'Check 3' 'openssl s_client -connect example.com:443 -servername example.com </dev/null 2>/dev/null | openssl x509 -noout -dates'
    ;;
  ol:7:28)
    run_check 'Check 1' 'date -u'
    run_check 'Check 2' 'openssl version'
    run_check 'Check 3' 'openssl s_client -connect example.com:443 -servername example.com </dev/null 2>/dev/null | openssl x509 -noout -dates'
    ;;
  ol:8:28)
    run_check 'Check 1' 'date -u'
    run_check 'Check 2' 'openssl version'
    run_check 'Check 3' 'openssl s_client -connect example.com:443 -servername example.com </dev/null 2>/dev/null | openssl x509 -noout -dates'
    ;;
  ol:9:28)
    run_check 'Check 1' 'date -u'
    run_check 'Check 2' 'openssl version'
    run_check 'Check 3' 'openssl s_client -connect example.com:443 -servername example.com </dev/null 2>/dev/null | openssl x509 -noout -dates'
    ;;
  rhel:7:28)
    run_check 'Check 1' 'date -u'
    run_check 'Check 2' 'openssl version'
    run_check 'Check 3' 'openssl s_client -connect example.com:443 -servername example.com </dev/null 2>/dev/null | openssl x509 -noout -dates'
    ;;
  rhel:8:28)
    run_check 'Check 1' 'date -u'
    run_check 'Check 2' 'openssl version'
    run_check 'Check 3' 'openssl s_client -connect example.com:443 -servername example.com </dev/null 2>/dev/null | openssl x509 -noout -dates'
    ;;
  rhel:9:28)
    run_check 'Check 1' 'date -u'
    run_check 'Check 2' 'openssl version'
    run_check 'Check 3' 'openssl s_client -connect example.com:443 -servername example.com </dev/null 2>/dev/null | openssl x509 -noout -dates'
    ;;
  ubuntu:20:29)
    run_check 'Check 1' 'sudo ufw status verbose 2>/dev/null'
    run_check 'Check 2' 'ss -lntp'
    run_check 'Check 3' 'sudo nft list ruleset 2>/dev/null | head -25'
    ;;
  ubuntu:22:29)
    run_check 'Check 1' 'sudo ufw status verbose 2>/dev/null'
    run_check 'Check 2' 'ss -lntp'
    run_check 'Check 3' 'sudo nft list ruleset 2>/dev/null | head -25'
    ;;
  ubuntu:24:29)
    run_check 'Check 1' 'sudo ufw status verbose 2>/dev/null'
    run_check 'Check 2' 'ss -lntp'
    run_check 'Check 3' 'sudo nft list ruleset 2>/dev/null | head -25'
    ;;
  ol:7:29)
    run_check 'Check 1' 'sudo firewall-cmd --state 2>/dev/null'
    run_check 'Check 2' 'sudo firewall-cmd --list-all 2>/dev/null'
    run_check 'Check 3' 'sudo firewall-cmd --get-active-zones 2>/dev/null'
    ;;
  ol:8:29)
    run_check 'Check 1' 'sudo firewall-cmd --state 2>/dev/null'
    run_check 'Check 2' 'sudo firewall-cmd --list-all 2>/dev/null'
    run_check 'Check 3' 'sudo firewall-cmd --get-active-zones 2>/dev/null'
    ;;
  ol:9:29)
    run_check 'Check 1' 'sudo firewall-cmd --state 2>/dev/null'
    run_check 'Check 2' 'sudo firewall-cmd --list-all 2>/dev/null'
    run_check 'Check 3' 'sudo firewall-cmd --get-active-zones 2>/dev/null'
    ;;
  rhel:7:29)
    run_check 'Check 1' 'sudo firewall-cmd --state 2>/dev/null'
    run_check 'Check 2' 'sudo firewall-cmd --list-all 2>/dev/null'
    run_check 'Check 3' 'sudo firewall-cmd --get-active-zones 2>/dev/null'
    ;;
  rhel:8:29)
    run_check 'Check 1' 'sudo firewall-cmd --state 2>/dev/null'
    run_check 'Check 2' 'sudo firewall-cmd --list-all 2>/dev/null'
    run_check 'Check 3' 'sudo firewall-cmd --get-active-zones 2>/dev/null'
    ;;
  rhel:9:29)
    run_check 'Check 1' 'sudo firewall-cmd --state 2>/dev/null'
    run_check 'Check 2' 'sudo firewall-cmd --list-all 2>/dev/null'
    run_check 'Check 3' 'sudo firewall-cmd --get-active-zones 2>/dev/null'
    ;;
  ubuntu:20:30)
    run_check 'Check 1' 'sudo aa-status 2>/dev/null | head -25'
    run_check 'Check 2' 'journalctl -k -b --no-pager | grep -i apparmor | tail'
    run_check 'Check 3' 'ls -l /etc/apparmor.d/ | head'
    ;;
  ubuntu:22:30)
    run_check 'Check 1' 'sudo aa-status 2>/dev/null | head -25'
    run_check 'Check 2' 'journalctl -k -b --no-pager | grep -i apparmor | tail'
    run_check 'Check 3' 'ls -l /etc/apparmor.d/ | head'
    ;;
  ubuntu:24:30)
    run_check 'Check 1' 'sudo aa-status 2>/dev/null | head -25'
    run_check 'Check 2' 'journalctl -k -b --no-pager | grep -i apparmor | tail'
    run_check 'Check 3' 'ls -l /etc/apparmor.d/ | head'
    ;;
  ol:7:30)
    run_check 'Check 1' 'getenforce 2>/dev/null'
    run_check 'Check 2' 'sudo ausearch -m AVC -ts recent 2>/dev/null | tail -20'
    run_check 'Check 3' 'ls -Zd /var/www /srv 2>/dev/null'
    ;;
  ol:8:30)
    run_check 'Check 1' 'getenforce 2>/dev/null'
    run_check 'Check 2' 'sudo ausearch -m AVC -ts recent 2>/dev/null | tail -20'
    run_check 'Check 3' 'ls -Zd /var/www /srv 2>/dev/null'
    ;;
  ol:9:30)
    run_check 'Check 1' 'getenforce 2>/dev/null'
    run_check 'Check 2' 'sudo ausearch -m AVC -ts recent 2>/dev/null | tail -20'
    run_check 'Check 3' 'ls -Zd /var/www /srv 2>/dev/null'
    ;;
  rhel:7:30)
    run_check 'Check 1' 'getenforce 2>/dev/null'
    run_check 'Check 2' 'sudo ausearch -m AVC -ts recent 2>/dev/null | tail -20'
    run_check 'Check 3' 'ls -Zd /var/www /srv 2>/dev/null'
    ;;
  rhel:8:30)
    run_check 'Check 1' 'getenforce 2>/dev/null'
    run_check 'Check 2' 'sudo ausearch -m AVC -ts recent 2>/dev/null | tail -20'
    run_check 'Check 3' 'ls -Zd /var/www /srv 2>/dev/null'
    ;;
  rhel:9:30)
    run_check 'Check 1' 'getenforce 2>/dev/null'
    run_check 'Check 2' 'sudo ausearch -m AVC -ts recent 2>/dev/null | tail -20'
    run_check 'Check 3' 'ls -Zd /var/www /srv 2>/dev/null'
    ;;
  ubuntu:20:31)
    run_check 'Check 1' 'namei -l /var/log'
    run_check 'Check 2' 'stat -c "%U %G %a %n" /var/log'
    run_check 'Check 3' 'getfacl /var/log 2>/dev/null | head'
    ;;
  ubuntu:22:31)
    run_check 'Check 1' 'namei -l /var/log'
    run_check 'Check 2' 'stat -c "%U %G %a %n" /var/log'
    run_check 'Check 3' 'getfacl /var/log 2>/dev/null | head'
    ;;
  ubuntu:24:31)
    run_check 'Check 1' 'namei -l /var/log'
    run_check 'Check 2' 'stat -c "%U %G %a %n" /var/log'
    run_check 'Check 3' 'getfacl /var/log 2>/dev/null | head'
    ;;
  ol:7:31)
    run_check 'Check 1' 'namei -l /var/log'
    run_check 'Check 2' 'stat -c "%A %U %G %n" /var/log'
    run_check 'Check 3' 'getfacl /var/log 2>/dev/null | head'
    ;;
  ol:8:31)
    run_check 'Check 1' 'namei -l /var/log'
    run_check 'Check 2' 'stat -c "%A %U %G %n" /var/log'
    run_check 'Check 3' 'getfacl /var/log 2>/dev/null | head'
    ;;
  ol:9:31)
    run_check 'Check 1' 'namei -l /var/log'
    run_check 'Check 2' 'stat -c "%A %U %G %n" /var/log'
    run_check 'Check 3' 'getfacl /var/log 2>/dev/null | head'
    ;;
  rhel:7:31)
    run_check 'Check 1' 'namei -l /var/log'
    run_check 'Check 2' 'stat -c "%A %U %G %n" /var/log'
    run_check 'Check 3' 'getfacl /var/log 2>/dev/null | head'
    ;;
  rhel:8:31)
    run_check 'Check 1' 'namei -l /var/log'
    run_check 'Check 2' 'stat -c "%A %U %G %n" /var/log'
    run_check 'Check 3' 'getfacl /var/log 2>/dev/null | head'
    ;;
  rhel:9:31)
    run_check 'Check 1' 'namei -l /var/log'
    run_check 'Check 2' 'stat -c "%A %U %G %n" /var/log'
    run_check 'Check 3' 'getfacl /var/log 2>/dev/null | head'
    ;;
  ubuntu:20:32)
    run_check 'Check 1' id
    run_check 'Check 2' 'sudo -l 2>&1 | head -30'
    run_check 'Check 3' 'ls -l /etc/sudoers /etc/sudoers.d/'
    ;;
  ubuntu:22:32)
    run_check 'Check 1' id
    run_check 'Check 2' 'sudo -l 2>&1 | head -30'
    run_check 'Check 3' 'ls -l /etc/sudoers /etc/sudoers.d/'
    ;;
  ubuntu:24:32)
    run_check 'Check 1' id
    run_check 'Check 2' 'sudo -l 2>&1 | head -30'
    run_check 'Check 3' 'ls -l /etc/sudoers /etc/sudoers.d/'
    ;;
  ol:7:32)
    run_check 'Check 1' id
    run_check 'Check 2' 'sudo -l 2>&1 | head -25'
    run_check 'Check 3' 'visudo -c 2>/dev/null'
    ;;
  ol:8:32)
    run_check 'Check 1' id
    run_check 'Check 2' 'sudo -l 2>&1 | head -25'
    run_check 'Check 3' 'visudo -c 2>/dev/null'
    ;;
  ol:9:32)
    run_check 'Check 1' id
    run_check 'Check 2' 'sudo -l 2>&1 | head -25'
    run_check 'Check 3' 'visudo -c 2>/dev/null'
    ;;
  rhel:7:32)
    run_check 'Check 1' id
    run_check 'Check 2' 'sudo -l 2>&1 | head -25'
    run_check 'Check 3' 'visudo -c 2>/dev/null'
    ;;
  rhel:8:32)
    run_check 'Check 1' id
    run_check 'Check 2' 'sudo -l 2>&1 | head -25'
    run_check 'Check 3' 'visudo -c 2>/dev/null'
    ;;
  rhel:9:32)
    run_check 'Check 1' id
    run_check 'Check 2' 'sudo -l 2>&1 | head -25'
    run_check 'Check 3' 'visudo -c 2>/dev/null'
    ;;
  ubuntu:20:33)
    run_check 'Check 1' 'cat /proc/sys/fs/file-nr'
    run_check 'Check 2' 'ulimit -n'
    run_check 'Check 3' 'systemctl show nginx -p LimitNOFILE 2>/dev/null'
    ;;
  ubuntu:22:33)
    run_check 'Check 1' 'cat /proc/sys/fs/file-nr'
    run_check 'Check 2' 'ulimit -n'
    run_check 'Check 3' 'systemctl show nginx -p LimitNOFILE 2>/dev/null'
    ;;
  ubuntu:24:33)
    run_check 'Check 1' 'cat /proc/sys/fs/file-nr'
    run_check 'Check 2' 'ulimit -n'
    run_check 'Check 3' 'systemctl show nginx -p LimitNOFILE 2>/dev/null'
    ;;
  ol:7:33)
    run_check 'Check 1' 'cat /proc/sys/fs/file-nr'
    run_check 'Check 2' 'ulimit -n'
    run_check 'Check 3' 'systemctl show nginx -p LimitNOFILE 2>/dev/null'
    ;;
  ol:8:33)
    run_check 'Check 1' 'cat /proc/sys/fs/file-nr'
    run_check 'Check 2' 'ulimit -n'
    run_check 'Check 3' 'systemctl show nginx -p LimitNOFILE 2>/dev/null'
    ;;
  ol:9:33)
    run_check 'Check 1' 'cat /proc/sys/fs/file-nr'
    run_check 'Check 2' 'ulimit -n'
    run_check 'Check 3' 'systemctl show nginx -p LimitNOFILE 2>/dev/null'
    ;;
  rhel:7:33)
    run_check 'Check 1' 'cat /proc/sys/fs/file-nr'
    run_check 'Check 2' 'ulimit -n'
    run_check 'Check 3' 'systemctl show nginx -p LimitNOFILE 2>/dev/null'
    ;;
  rhel:8:33)
    run_check 'Check 1' 'cat /proc/sys/fs/file-nr'
    run_check 'Check 2' 'ulimit -n'
    run_check 'Check 3' 'systemctl show nginx -p LimitNOFILE 2>/dev/null'
    ;;
  rhel:9:33)
    run_check 'Check 1' 'cat /proc/sys/fs/file-nr'
    run_check 'Check 2' 'ulimit -n'
    run_check 'Check 3' 'systemctl show nginx -p LimitNOFILE 2>/dev/null'
    ;;
  ubuntu:20:34)
    run_check 'Check 1' 'timedatectl status'
    run_check 'Check 2' 'systemctl is-active systemd-timesyncd 2>/dev/null'
    run_check 'Check 3' 'systemctl is-active chrony 2>/dev/null'
    ;;
  ubuntu:22:34)
    run_check 'Check 1' 'timedatectl status'
    run_check 'Check 2' 'systemctl is-active systemd-timesyncd 2>/dev/null'
    run_check 'Check 3' 'systemctl is-active chrony 2>/dev/null'
    ;;
  ubuntu:24:34)
    run_check 'Check 1' 'timedatectl status'
    run_check 'Check 2' 'systemctl is-active systemd-timesyncd 2>/dev/null'
    run_check 'Check 3' 'systemctl is-active chrony 2>/dev/null'
    ;;
  ol:7:34)
    run_check 'Check 1' 'timedatectl status'
    run_check 'Check 2' 'systemctl status chronyd --no-pager'
    run_check 'Check 3' 'chronyc tracking 2>/dev/null'
    ;;
  ol:8:34)
    run_check 'Check 1' 'timedatectl status'
    run_check 'Check 2' 'systemctl status chronyd --no-pager'
    run_check 'Check 3' 'chronyc tracking 2>/dev/null'
    ;;
  ol:9:34)
    run_check 'Check 1' 'timedatectl status'
    run_check 'Check 2' 'systemctl status chronyd --no-pager'
    run_check 'Check 3' 'chronyc tracking 2>/dev/null'
    ;;
  rhel:7:34)
    run_check 'Check 1' 'timedatectl status'
    run_check 'Check 2' 'systemctl status chronyd --no-pager'
    run_check 'Check 3' 'chronyc tracking 2>/dev/null'
    ;;
  rhel:8:34)
    run_check 'Check 1' 'timedatectl status'
    run_check 'Check 2' 'systemctl status chronyd --no-pager'
    run_check 'Check 3' 'chronyc tracking 2>/dev/null'
    ;;
  rhel:9:34)
    run_check 'Check 1' 'timedatectl status'
    run_check 'Check 2' 'systemctl status chronyd --no-pager'
    run_check 'Check 3' 'chronyc tracking 2>/dev/null'
    ;;
  ubuntu:20:35)
    run_check 'Check 1' 'find /backup -maxdepth 2 -type f -printf "%TY-%Tm-%Td %s %p\n" 2>/dev/null | tail'
    run_check 'Check 2' 'df -h /backup'
    run_check 'Check 3' 'sha256sum /etc/os-release'
    ;;
  ubuntu:22:35)
    run_check 'Check 1' 'find /backup -maxdepth 2 -type f -printf "%TY-%Tm-%Td %s %p\n" 2>/dev/null | tail'
    run_check 'Check 2' 'df -h /backup'
    run_check 'Check 3' 'sha256sum /etc/os-release'
    ;;
  ubuntu:24:35)
    run_check 'Check 1' 'find /backup -maxdepth 2 -type f -printf "%TY-%Tm-%Td %s %p\n" 2>/dev/null | tail'
    run_check 'Check 2' 'df -h /backup'
    run_check 'Check 3' 'sha256sum /etc/os-release'
    ;;
  ol:7:35)
    run_check 'Check 1' 'find /backup -maxdepth 2 -type f -printf "%TY-%Tm-%Td %s %p\n" 2>/dev/null | tail'
    run_check 'Check 2' 'df -h /backup'
    run_check 'Check 3' 'sha256sum /etc/os-release'
    ;;
  ol:8:35)
    run_check 'Check 1' 'find /backup -maxdepth 2 -type f -printf "%TY-%Tm-%Td %s %p\n" 2>/dev/null | tail'
    run_check 'Check 2' 'df -h /backup'
    run_check 'Check 3' 'sha256sum /etc/os-release'
    ;;
  ol:9:35)
    run_check 'Check 1' 'find /backup -maxdepth 2 -type f -printf "%TY-%Tm-%Td %s %p\n" 2>/dev/null | tail'
    run_check 'Check 2' 'df -h /backup'
    run_check 'Check 3' 'sha256sum /etc/os-release'
    ;;
  rhel:7:35)
    run_check 'Check 1' 'find /backup -maxdepth 2 -type f -printf "%TY-%Tm-%Td %s %p\n" 2>/dev/null | tail'
    run_check 'Check 2' 'df -h /backup'
    run_check 'Check 3' 'sha256sum /etc/os-release'
    ;;
  rhel:8:35)
    run_check 'Check 1' 'find /backup -maxdepth 2 -type f -printf "%TY-%Tm-%Td %s %p\n" 2>/dev/null | tail'
    run_check 'Check 2' 'df -h /backup'
    run_check 'Check 3' 'sha256sum /etc/os-release'
    ;;
  rhel:9:35)
    run_check 'Check 1' 'find /backup -maxdepth 2 -type f -printf "%TY-%Tm-%Td %s %p\n" 2>/dev/null | tail'
    run_check 'Check 2' 'df -h /backup'
    run_check 'Check 3' 'sha256sum /etc/os-release'
    ;;
  ubuntu:20:36)
    run_check 'Check 1' 'dpkg-query -W qemu-guest-agent 2>/dev/null'
    run_check 'Check 2' 'systemctl status qemu-guest-agent --no-pager'
    run_check 'Check 3' 'ls /dev/virtio-ports/ 2>/dev/null'
    ;;
  ubuntu:22:36)
    run_check 'Check 1' 'dpkg-query -W qemu-guest-agent 2>/dev/null'
    run_check 'Check 2' 'systemctl status qemu-guest-agent --no-pager'
    run_check 'Check 3' 'ls /dev/virtio-ports/ 2>/dev/null'
    ;;
  ubuntu:24:36)
    run_check 'Check 1' 'dpkg-query -W qemu-guest-agent 2>/dev/null'
    run_check 'Check 2' 'systemctl status qemu-guest-agent --no-pager'
    run_check 'Check 3' 'ls /dev/virtio-ports/ 2>/dev/null'
    ;;
  ol:7:36)
    run_check 'Check 1' 'rpm -q qemu-guest-agent'
    run_check 'Check 2' 'systemctl status qemu-guest-agent --no-pager'
    run_check 'Check 3' 'ls /dev/virtio-ports/ 2>/dev/null'
    ;;
  ol:8:36)
    run_check 'Check 1' 'rpm -q qemu-guest-agent'
    run_check 'Check 2' 'systemctl status qemu-guest-agent --no-pager'
    run_check 'Check 3' 'ls /dev/virtio-ports/ 2>/dev/null'
    ;;
  ol:9:36)
    run_check 'Check 1' 'rpm -q qemu-guest-agent'
    run_check 'Check 2' 'systemctl status qemu-guest-agent --no-pager'
    run_check 'Check 3' 'ls /dev/virtio-ports/ 2>/dev/null'
    ;;
  rhel:7:36)
    run_check 'Check 1' 'rpm -q qemu-guest-agent'
    run_check 'Check 2' 'systemctl status qemu-guest-agent --no-pager'
    run_check 'Check 3' 'ls /dev/virtio-ports/ 2>/dev/null'
    ;;
  rhel:8:36)
    run_check 'Check 1' 'rpm -q qemu-guest-agent'
    run_check 'Check 2' 'systemctl status qemu-guest-agent --no-pager'
    run_check 'Check 3' 'ls /dev/virtio-ports/ 2>/dev/null'
    ;;
  rhel:9:36)
    run_check 'Check 1' 'rpm -q qemu-guest-agent'
    run_check 'Check 2' 'systemctl status qemu-guest-agent --no-pager'
    run_check 'Check 3' 'ls /dev/virtio-ports/ 2>/dev/null'
    ;;
  ubuntu:20:37)
    run_check 'Check 1' 'docker ps -a 2>/dev/null | head'
    run_check 'Check 2' 'podman ps -a 2>/dev/null | head'
    run_check 'Check 3' 'ss -lntp | head'
    ;;
  ubuntu:22:37)
    run_check 'Check 1' 'docker ps -a 2>/dev/null | head'
    run_check 'Check 2' 'podman ps -a 2>/dev/null | head'
    run_check 'Check 3' 'ss -lntp | head'
    ;;
  ubuntu:24:37)
    run_check 'Check 1' 'docker ps -a 2>/dev/null | head'
    run_check 'Check 2' 'podman ps -a 2>/dev/null | head'
    run_check 'Check 3' 'ss -lntp | head'
    ;;
  ol:7:37)
    run_check 'Check 1' 'docker ps -a 2>/dev/null | head'
    run_check 'Check 2' 'podman ps -a 2>/dev/null | head'
    run_check 'Check 3' 'ss -lntp | head'
    ;;
  ol:8:37)
    run_check 'Check 1' 'docker ps -a 2>/dev/null | head'
    run_check 'Check 2' 'podman ps -a 2>/dev/null | head'
    run_check 'Check 3' 'ss -lntp | head'
    ;;
  ol:9:37)
    run_check 'Check 1' 'docker ps -a 2>/dev/null | head'
    run_check 'Check 2' 'podman ps -a 2>/dev/null | head'
    run_check 'Check 3' 'ss -lntp | head'
    ;;
  rhel:7:37)
    run_check 'Check 1' 'docker ps -a 2>/dev/null | head'
    run_check 'Check 2' 'podman ps -a 2>/dev/null | head'
    run_check 'Check 3' 'ss -lntp | head'
    ;;
  rhel:8:37)
    run_check 'Check 1' 'docker ps -a 2>/dev/null | head'
    run_check 'Check 2' 'podman ps -a 2>/dev/null | head'
    run_check 'Check 3' 'ss -lntp | head'
    ;;
  rhel:9:37)
    run_check 'Check 1' 'docker ps -a 2>/dev/null | head'
    run_check 'Check 2' 'podman ps -a 2>/dev/null | head'
    run_check 'Check 3' 'ss -lntp | head'
    ;;
  ubuntu:20:38)
    run_check 'Check 1' 'df -hT'
    run_check 'Check 2' 'lsblk -o NAME,TYPE,SIZE,MOUNTPOINT'
    run_check 'Check 3' 'echo "Device placeholder: choose an actual disk first" 2>/dev/null | head'
    ;;
  ubuntu:22:38)
    run_check 'Check 1' 'df -hT'
    run_check 'Check 2' 'lsblk -o NAME,TYPE,SIZE,MOUNTPOINT'
    run_check 'Check 3' 'echo "Device placeholder: choose an actual disk first" 2>/dev/null | head'
    ;;
  ubuntu:24:38)
    run_check 'Check 1' 'df -hT'
    run_check 'Check 2' 'lsblk -o NAME,TYPE,SIZE,MOUNTPOINT'
    run_check 'Check 3' 'echo "Device placeholder: choose an actual disk first" 2>/dev/null | head'
    ;;
  ol:7:38)
    run_check 'Check 1' 'df -hT'
    run_check 'Check 2' 'lsblk -o NAME,TYPE,SIZE,MOUNTPOINT'
    run_check 'Check 3' 'echo "Device placeholder: choose an actual disk first" 2>/dev/null | head'
    ;;
  ol:8:38)
    run_check 'Check 1' 'df -hT'
    run_check 'Check 2' 'lsblk -o NAME,TYPE,SIZE,MOUNTPOINT'
    run_check 'Check 3' 'echo "Device placeholder: choose an actual disk first" 2>/dev/null | head'
    ;;
  ol:9:38)
    run_check 'Check 1' 'df -hT'
    run_check 'Check 2' 'lsblk -o NAME,TYPE,SIZE,MOUNTPOINT'
    run_check 'Check 3' 'echo "Device placeholder: choose an actual disk first" 2>/dev/null | head'
    ;;
  rhel:7:38)
    run_check 'Check 1' 'df -hT'
    run_check 'Check 2' 'lsblk -o NAME,TYPE,SIZE,MOUNTPOINT'
    run_check 'Check 3' 'echo "Device placeholder: choose an actual disk first" 2>/dev/null | head'
    ;;
  rhel:8:38)
    run_check 'Check 1' 'df -hT'
    run_check 'Check 2' 'lsblk -o NAME,TYPE,SIZE,MOUNTPOINT'
    run_check 'Check 3' 'echo "Device placeholder: choose an actual disk first" 2>/dev/null | head'
    ;;
  rhel:9:38)
    run_check 'Check 1' 'df -hT'
    run_check 'Check 2' 'lsblk -o NAME,TYPE,SIZE,MOUNTPOINT'
    run_check 'Check 3' 'echo "Device placeholder: choose an actual disk first" 2>/dev/null | head'
    ;;
  ubuntu:20:39)
    run_check 'Check 1' 'free -h'
    run_check 'Check 2' 'cat /proc/meminfo | head'
    run_check 'Check 3' 'vmstat 1 2'
    ;;
  ubuntu:22:39)
    run_check 'Check 1' 'free -h'
    run_check 'Check 2' 'cat /proc/meminfo | head'
    run_check 'Check 3' 'vmstat 1 2'
    ;;
  ubuntu:24:39)
    run_check 'Check 1' 'free -h'
    run_check 'Check 2' 'cat /proc/meminfo | head'
    run_check 'Check 3' 'vmstat 1 2'
    ;;
  ol:7:39)
    run_check 'Check 1' 'free -h'
    run_check 'Check 2' 'cat /proc/meminfo | head'
    run_check 'Check 3' 'vmstat 1 2'
    ;;
  ol:8:39)
    run_check 'Check 1' 'free -h'
    run_check 'Check 2' 'cat /proc/meminfo | head'
    run_check 'Check 3' 'vmstat 1 2'
    ;;
  ol:9:39)
    run_check 'Check 1' 'free -h'
    run_check 'Check 2' 'cat /proc/meminfo | head'
    run_check 'Check 3' 'vmstat 1 2'
    ;;
  rhel:7:39)
    run_check 'Check 1' 'free -h'
    run_check 'Check 2' 'cat /proc/meminfo | head'
    run_check 'Check 3' 'vmstat 1 2'
    ;;
  rhel:8:39)
    run_check 'Check 1' 'free -h'
    run_check 'Check 2' 'cat /proc/meminfo | head'
    run_check 'Check 3' 'vmstat 1 2'
    ;;
  rhel:9:39)
    run_check 'Check 1' 'free -h'
    run_check 'Check 2' 'cat /proc/meminfo | head'
    run_check 'Check 3' 'vmstat 1 2'
    ;;
  ubuntu:20:40)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'top -b -n 1 | head -15'
    run_check 'Check 3' 'cat /proc/stat | head -2'
    ;;
  ubuntu:22:40)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'top -b -n 1 | head -15'
    run_check 'Check 3' 'cat /proc/stat | head -2'
    ;;
  ubuntu:24:40)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'top -b -n 1 | head -15'
    run_check 'Check 3' 'cat /proc/stat | head -2'
    ;;
  ol:7:40)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'top -b -n 1 | head -15'
    run_check 'Check 3' 'cat /proc/stat | head -2'
    ;;
  ol:8:40)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'top -b -n 1 | head -15'
    run_check 'Check 3' 'cat /proc/stat | head -2'
    ;;
  ol:9:40)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'top -b -n 1 | head -15'
    run_check 'Check 3' 'cat /proc/stat | head -2'
    ;;
  rhel:7:40)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'top -b -n 1 | head -15'
    run_check 'Check 3' 'cat /proc/stat | head -2'
    ;;
  rhel:8:40)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'top -b -n 1 | head -15'
    run_check 'Check 3' 'cat /proc/stat | head -2'
    ;;
  rhel:9:40)
    run_check 'Check 1' 'uptime; nproc'
    run_check 'Check 2' 'top -b -n 1 | head -15'
    run_check 'Check 3' 'cat /proc/stat | head -2'
    ;;
  *) echo "Unsupported release. Inspect commands manually; no fallback executed." >&2; exit 2 ;;
esac
exit 0
